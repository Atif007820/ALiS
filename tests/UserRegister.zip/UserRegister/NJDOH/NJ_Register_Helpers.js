import { writeFileSync, mkdirSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { faker } from '@faker-js/faker';

const currentFile = fileURLToPath(import.meta.url);
const njRoot = dirname(dirname(currentFile));

export const LOGIN_URL = 'http://172.16.3.2/ALiSNJDOH2TESTING11.4.37.03/LoginNJ.aspx';
export const DEFAULT_PASSWORD = 'Password@1';
export const PRIMARY_EMAIL = 'mohdatif.jamal@ops1.advancedgrc.com';
export const ALT_EMAIL = 'mohdatif.jamal@ops1.advancedgrc.com';
export const USER_DATA_DIR = join(njRoot, 'testData');

export const PRODUCT_CONFIGS = [
  {
    abbreviation: 'CL',
    portalText: 'Clinical Laboratory',
    entityPrefix: 'CL',
    entityFields: ['Laboratory Name', 'Registered Legal Business Name'],
  },
  {
    abbreviation: 'BB',
    portalText: 'Blood Bank',
    entityPrefix: 'BB',
    entityFields: ['Facility Name (Legal Name)', 'Facility Name (DBA Name)'],
  },
  {
    abbreviation: 'HMB',
    portalText: 'Human Milk Bank',
    entityPrefix: 'HMB',
    entityFields: ['Entity Name (Legal Name)', 'Entity Name (DBA Name)'],
  },
  {
    abbreviation: 'ESF',
    portalText: 'Embryo Storage Facility',
    entityPrefix: 'ESF_',
    entityFields: ['Entity Name (Legal Name)', 'Entity Name (DBA Name)'],
  },
];

const SIMPLE_NAMES = [
  'John', 'Mike', 'David', 'James', 'Robert',
  'Chris', 'Mark', 'Paul', 'Steve', 'Kevin',
  'Brian', 'Adam', 'Eric', 'Ryan', 'Jason',
  'Mary', 'Linda', 'Susan', 'Karen', 'Lisa',
  'Sarah', 'Nancy', 'Laura', 'Amy', 'Emma',
];

const SIMPLE_LAST_NAMES = [
  'Smith', 'Brown', 'Davis', 'Wilson', 'Taylor',
  'Moore', 'Clark', 'Hall', 'White', 'Green',
  'Baker', 'King', 'Lee', 'Hill', 'Young',
];

const US_CITIES = [
  'Newark', 'Trenton', 'Jersey City', 'Paterson', 'Edison',
  'Camden', 'Clifton', 'Elizabeth', 'Hoboken', 'Princeton',
];
const LOGIN_DIGIT_LENGTHS = [1, 2, 3, 5, 6, 7, 8];

export const pick = (items) => faker.helpers.arrayElement(items);
export const randDigits = (length) => Array.from({ length }, () => Math.floor(Math.random() * 10)).join('');

export const randomPhone = () => `${randDigits(3)}-${randDigits(3)}-${randDigits(4)}`;
export const randomZip = () => `${randDigits(5)}-${randDigits(4)}`;
export const randomStreet = () => `${randDigits(3)} ${pick(['Main', 'Market', 'Broad', 'State'])} Street`;
export const randomUnit = () => `${pick(['Suite', 'Apt', 'Unit'])} ${randDigits(2)}`;
export const randomCity = () => pick(US_CITIES);
export const randomLoginName = (digitLength = 1) => `${pick(SIMPLE_NAMES)}${randomNumberWithDigitLength(digitLength)}`;

export function timestampParts() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, '0');
  const hours24 = now.getHours();
  const hours12 = hours24 % 12 || 12;
  const ampm = hours24 >= 12 ? 'PM' : 'AM';

  return {
    date: `${pad(now.getDate())}-${pad(now.getMonth() + 1)}-${now.getFullYear()}`,
    time: `${pad(hours12)}:${pad(now.getMinutes())}:${pad(now.getSeconds())} ${ampm}`,
  };
}

export function buildEntityName(prefix) {
  const { date, time } = timestampParts();
  return `${prefix}_${date}_${time}`;
}

export function buildUser(product) {
  const firstName = pick(SIMPLE_NAMES);
  const lastName = pick(SIMPLE_LAST_NAMES);

  return {
    product: product.abbreviation,
    portalText: product.portalText,
    entityName: buildEntityName(product.entityPrefix),
    firstName,
    lastName,
    emailId: PRIMARY_EMAIL,
    streetOne: randomStreet(),
    streetTwo: randomUnit(),
    city: randomCity(),
    zip: randomZip(),
    county: '14',
    phone: randomPhone(),
    fax: randomPhone(),
    email: ALT_EMAIL,
    altEmail: ALT_EMAIL,
    loginName: randomLoginName(),
    password: DEFAULT_PASSWORD,
  };
}

export function saveRegisteredUser(user) {
  const filePath = join(USER_DATA_DIR, `lastRegistered${user.product}User.json`);
  mkdirSync(dirname(filePath), { recursive: true });
  writeFileSync(filePath, `${JSON.stringify(user, null, 2)}\n`, 'utf-8');
  return filePath;
}

export async function waitForPageReady(page) {
  await page.waitForLoadState('domcontentloaded').catch(() => {});
  await page.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
  await waitForAspNetIdle(page);
}

export async function waitForAspNetIdle(page) {
  await page.evaluate(() => new Promise((resolve) => {
    const mgr = window.Sys?.WebForms?.PageRequestManager?.getInstance?.();
    if (!mgr || !mgr.get_isInAsyncPostBack()) {
      resolve();
      return;
    }

    const interval = setInterval(() => {
      if (!mgr.get_isInAsyncPostBack()) {
        clearInterval(interval);
        resolve();
      }
    }, 50);

    setTimeout(() => {
      clearInterval(interval);
      resolve();
    }, 15000);
  })).catch(() => {});

  await page.waitForTimeout(250);
}

export async function fillText(locator, value) {
  const { expect } = await import('@playwright/test');
  await expect(locator).toBeVisible();
  await expect(locator).toBeEnabled();
  await locator.scrollIntoViewIfNeeded().catch(() => {});
  await locator.fill(String(value));
}

export async function selectOption(locator, value) {
  const { expect } = await import('@playwright/test');
  await expect(locator).toBeVisible();
  await expect(locator).toBeEnabled();
  await locator.scrollIntoViewIfNeeded().catch(() => {});
  await locator.selectOption(String(value));
}

export async function clickAndWait(page, locator) {
  await locator.scrollIntoViewIfNeeded().catch(() => {});
  await locator.click();
  await waitForPageReady(page);
}

export async function getVisibleValidationText(page) {
  const validationText = await page
    .locator('li, .validation-summary-errors, .field-validation-error, [id*="ValidationSummary"], [id*="valSummary"]')
    .evaluateAll((elements) => elements.map((element) => element.textContent ?? '').join('\n'))
    .catch(() => '');

  return validationText
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => /required|invalid|does not match|already|unique|taken/i.test(line))
    .filter((line) => !/Fields marked|Password is case sensitive/i.test(line))
    .join(' ');
}

export async function isDuplicateLoginVisible(page) {
  const bodyText = await page.locator('body').innerText().catch(() => '');
  return /login name.*(already|exists|unique|taken)|already.*login name/i.test(bodyText);
}

export function nextDifferentLoginName(previousLoginName, attemptIndex = 1) {
  const previousName = previousLoginName.replace(/\d+$/, '');
  const digitLengthIndex = Math.max(0, attemptIndex - 1);
  const digitLength = LOGIN_DIGIT_LENGTHS[Math.min(digitLengthIndex, LOGIN_DIGIT_LENGTHS.length - 1)];
  let nextLoginName;

  do {
    nextLoginName = randomLoginName(digitLength);
  } while (
    nextLoginName === previousLoginName ||
    nextLoginName.replace(/\d+$/, '') === previousName
  );

  return nextLoginName;
}

function randomNumberWithDigitLength(length) {
  if (length <= 1) {
    return String(Math.floor(Math.random() * 9) + 1);
  }

  const min = 10 ** (length - 1);
  const max = (10 ** length) - 1;
  return String(Math.floor(Math.random() * (max - min + 1)) + min);
}
