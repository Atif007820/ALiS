import { expect, test } from '@playwright/test';
import {
  LOGIN_URL,
  PRODUCT_CONFIGS,
  buildUser,
  clickAndWait,
  fillText,
  getVisibleValidationText,
  isDuplicateLoginVisible,
  nextDifferentLoginName,
  saveRegisteredUser,
  selectOption,
  waitForPageReady,
} from './NJ_Register_Helpers.js';

async function openProductRegistration(page, product) {
  await page.goto(LOGIN_URL, { waitUntil: 'domcontentloaded' });
  await expect(page.getByRole('row', { name: /USER LOGIN\s+Login Name/ }).first()).toBeVisible();
  await clickAndWait(page, page.getByText(product.portalText, { exact: true }));
  await expect(page.getByRole('row', { name: /USER LOGIN\s+Login Name/ }).first()).toBeVisible();
  await clickAndWait(page, page.getByRole('link', { name: 'Click Here' }));
  await expect(page.getByRole('region', { name: 'banner' })).toBeVisible();
}

async function fillEntityFields(page, product, user) {
  for (const fieldName of product.entityFields) {
    await fillText(page.getByRole('textbox', { name: fieldName }), user.entityName);
  }
}

async function fillContactAndAddress(page, user) {
  await fillText(page.getByRole('textbox', { name: 'Last Name' }), user.lastName);
  await fillText(page.getByRole('textbox', { name: 'First Name' }), user.firstName);
  await fillText(page.getByRole('textbox', { name: 'Email ID' }), user.emailId);
  await fillText(page.getByRole('textbox', { name: 'Street One' }), user.streetOne);
  await fillText(page.getByRole('textbox', { name: 'Street Two' }), user.streetTwo);
  await fillText(page.getByRole('textbox', { name: 'City' }), user.city);

  const zipField = page.getByRole('textbox', { name: 'Zip' });
  await fillText(zipField, user.zip);
  await zipField.press('Tab').catch(() => {});
  await waitForPageReady(page);

  await selectOption(page.getByLabel(/^County\s*\*?$/), user.county);
  await waitForPageReady(page);

  await fillText(page.getByRole('textbox', { name: 'Phone', exact: true }), user.phone);
  await fillText(page.getByRole('textbox', { name: 'Fax' }), user.fax);
  await fillText(page.getByRole('textbox', { name: 'Email', exact: true }), user.email);
  await fillText(page.getByRole('textbox', { name: 'Alt Email' }), user.altEmail);
}

async function fillAccount(page, user) {
  await fillText(page.getByRole('textbox', { name: /Login Name\s*\*/ }), user.loginName);
  await fillText(page.getByRole('textbox', { name: /^Password\s*\*/ }), user.password);
  await fillText(page.getByRole('textbox', { name: /Re-type Password\s*\*/ }), user.password);
}

async function submitWithUniqueLogin(page, user) {
  for (let attempt = 1; attempt <= 10; attempt++) {
    await fillAccount(page, user);
    await clickAndWait(page, page.getByRole('link', { name: 'Register' }));

    if (await isDuplicateLoginVisible(page)) {
      const oldLoginName = user.loginName;
      user.loginName = nextDifferentLoginName(oldLoginName, attempt);
      console.warn(`Login name already taken. Retrying ${oldLoginName} -> ${user.loginName}`);
      continue;
    }

    const validationText = await getVisibleValidationText(page);
    if (validationText) {
      throw new Error(`Registration failed validation: ${validationText}`);
    }

    return user;
  }

  throw new Error('Registration failed: duplicate login name was still shown after 10 attempts.');
}

async function registerProduct(page, product, testInfo) {
  const user = buildUser(product);

  testInfo.annotations.push({ type: 'Product', description: product.portalText });
  testInfo.annotations.push({ type: 'Abbreviation', description: product.abbreviation });
  testInfo.annotations.push({ type: 'Entity', description: user.entityName });
  testInfo.annotations.push({ type: 'Login Name', description: user.loginName });

  console.log(`\n-- NJ-${product.abbreviation} Registration --------------------------`);
  console.log('Product   :', product.portalText);
  console.log('Entity    :', user.entityName);
  console.log('Login Name:', user.loginName);
  console.log('---------------------------------------------------------------');

  await openProductRegistration(page, product);
  await fillEntityFields(page, product, user);
  await fillContactAndAddress(page, user);

  const registeredUser = await submitWithUniqueLogin(page, user);
  const userDataPath = saveRegisteredUser(registeredUser);
  console.log(`Credentials saved -> ${userDataPath}`);
}

test.describe('NJ User Registration', () => {
  for (const product of PRODUCT_CONFIGS) {
    test(`Register ${product.portalText} @${product.abbreviation}`, async ({ page }, testInfo) => {
      await registerProduct(page, product, testInfo);
    });
  }
});
