import { mkdirSync, writeFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { faker } from '@faker-js/faker';

const currentFile = fileURLToPath(import.meta.url);
const testsRoot = dirname(dirname(currentFile));

export const LOGIN_URL = 'http://172.16.3.2/ALiSTXOCA2TESTING11.4.37.03/Login.aspx';
export const DEFAULT_PASSWORD = 'Password@1';
export const PRIMARY_EMAIL = 'mohdatif.jamal@ops1.advancedgrc.com';
export const ALT_EMAIL = 'mohdatif.jamal@ops1.advancedgrc.com';
export const USER_DATA_DIR = join(testsRoot, 'testData');

export const PRODUCT_CONFIGS = [
  {
    abbreviation: 'GRD',
    productName: 'Guardianship',
    tabText: 'Register A Guardianship',
    registrationLinkId: 'Test_TabGuardianRegister_LinkButton24',
    loginPrefix: 'guardianship',
  },
  {
    abbreviation: 'CF',
    productName: 'Guardianship as a Corporate Fiduciary',
    tabText: 'Register A Guardianship',
    registrationLinkId: 'Test_TabGuardianRegister_LinkButton1',
    loginPrefix: 'fiduciary',
  },
  {
    abbreviation: 'CR',
    productName: 'Court Reporters',
    tabText: 'Court Reporters',
    registrationLinkId: 'Test_tabCredentialDetail_LinkButton11',
    loginPrefix: 'CR_',
  },
  {
    abbreviation: 'PS',
    productName: 'Process Servers',
    tabText: 'Process Servers',
    registrationLinkId: 'Test_TabPanel_lnkFoodEstablishmentPermit',
    loginPrefix: 'PS_',
  },
  {
    abbreviation: 'CI',
    productName: 'Court Interpreters',
    tabText: 'Court Interpreters',
    registrationLinkId: 'Test_tabRevenue_lnkInitialEMT',
    loginPrefix: 'CI_',
  },
  {
    abbreviation: 'CG',
    productName: 'Certified Guardians',
    tabText: 'Certified Guardians',
    registrationLinkId: 'Test_TabPanelGuardianShipRegistry_LinkButton20',
    loginPrefix: 'CG_',
  },
];

const FIRST_NAMES = ['John', 'Mike', 'David', 'Sarah', 'Emma', 'Mary', 'Linda', 'Robert', 'James', 'Peter', 'Lisa', 'Anna', 'Mark', 'Paul'];
const LAST_NAMES = ['Smith', 'Brown', 'Davis', 'Wilson', 'Taylor', 'Moore', 'Clark', 'Hall', 'White', 'Green', 'Baker', 'King', 'Lee', 'Hill'];
const TEXAS_CITIES = ['Austin', 'Dallas', 'Houston', 'San Antonio', 'Fort Worth', 'Plano'];
const LOGIN_DIGIT_LENGTHS = [1, 2, 3, 5, 6, 7, 8];

export const pick = (items) => faker.helpers.arrayElement(items);
export const randDigits = (length) => Array.from({ length }, () => Math.floor(Math.random() * 10)).join('');
export const randomPhone = () => `${randDigits(3)}-${randDigits(3)}-${randDigits(4)}`;
export const randomZip = () => `${randDigits(5)}-${randDigits(4)}`;
export const randomStreet = () => `${randDigits(3)} ${pick(['Main', 'Market', 'Broad', 'State'])} Street`;
export const randomUnit = () => `${pick(['Suite', 'Apt', 'Unit'])} ${randDigits(2)}`;
export const randomCity = () => pick(TEXAS_CITIES);

export function currentDateParts() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, '0');
  const hours24 = now.getHours();
  const hours12 = hours24 % 12 || 12;
  const ampm = hours24 >= 12 ? 'PM' : 'AM';

  return {
    dateForName: `${pad(now.getDate())}-${pad(now.getMonth() + 1)}-${now.getFullYear()}`,
    dateForField: `${pad(now.getMonth() + 1)}/${pad(now.getDate())}/${now.getFullYear()}`,
    timeForName: `${pad(hours12)}:${pad(now.getMinutes())}:${pad(now.getSeconds())} ${ampm}`,
  };
}

export function buildEntityName(product) {
  const { dateForName, timeForName } = currentDateParts();
  return `${product.abbreviation}_${dateForName}_${timeForName}`;
}

export function buildLoginName(product, digitLength = 1) {
  return `${product.loginPrefix}${randomNumberWithDigitLength(digitLength)}`;
}

export function buildUser(product) {
  const { dateForField } = currentDateParts();
  const nameTracker = { usedNameKeys: [] };
  const { firstName, lastName } = buildSimpleName(nameTracker);

  return {
    product: product.abbreviation,
    productName: product.productName,
    entityName: buildEntityName(product),
    firstName,
    lastName,
    fullName: `${firstName} ${lastName}`,
    date: dateForField,
    email: PRIMARY_EMAIL,
    altEmail: ALT_EMAIL,
    streetOne: randomStreet(),
    streetTwo: randomUnit(),
    city: randomCity(),
    state: 'TX',
    zip: randomZip(),
    phone: randomPhone(),
    fax: randomPhone(),
    loginName: buildLoginName(product),
    password: DEFAULT_PASSWORD,
    usedNameKeys: nameTracker.usedNameKeys,
  };
}

export function refreshSimpleProfileData(product, user) {
  const { firstName, lastName } = buildSimpleName(user);

  user.firstName = firstName;
  user.lastName = lastName;
  user.fullName = `${firstName} ${lastName}`;
  user.entityName = buildEntityName(product);
  user.email = PRIMARY_EMAIL;
  user.altEmail = ALT_EMAIL;
  user.streetOne = randomStreet();
  user.streetTwo = randomUnit();
  user.city = randomCity();
  user.zip = randomZip();
  user.phone = randomPhone();
  user.fax = randomPhone();

  return user;
}

export function saveRegisteredUser(user) {
  const filePath = join(USER_DATA_DIR, `lastRegisteredTXOCA${user.product}User.json`);
  mkdirSync(dirname(filePath), { recursive: true });
  const { usedNameKeys, ...savedUser } = user;
  writeFileSync(filePath, `${JSON.stringify(savedUser, null, 2)}\n`, 'utf-8');
  return filePath;
}

export async function waitForPageReady(page) {
  await page.waitForLoadState('domcontentloaded').catch(() => {});
  await page.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
  await waitForAspNetIdle(page);
}

export async function waitForAspNetIdle(page) {
  await page.evaluate(() => new Promise((resolve) => {
    const mgr = window.Sys?.WebForms?.PageRequestManager?.getInstance?.();
    if (!mgr || !mgr.get_isInAsyncPostBack()) {
      resolve();
      return;
    }

    const interval = setInterval(() => {
      if (!mgr.get_isInAsyncPostBack()) {
        clearInterval(interval);
        resolve();
      }
    }, 50);

    setTimeout(() => {
      clearInterval(interval);
      resolve();
    }, 15000);
  })).catch(() => {});

  await page.waitForTimeout(300);
}

export async function clickAndWait(page, locator) {
  await locator.scrollIntoViewIfNeeded().catch(() => {});
  await locator.click({ noWaitAfter: true });
  await waitForPageReady(page);
}

export async function fillText(locator, value) {
  const { expect } = await import('@playwright/test');
  const target = locator.first();
  await expect(target).toBeVisible();
  await expect(target).toBeEnabled();
  await target.scrollIntoViewIfNeeded().catch(() => {});
  await target.fill(String(value));
  return true;
}

export async function fillFirstText(page, names, value) {
  for (const name of names) {
    const pattern = name instanceof RegExp ? name : new RegExp(`^${escapeRegex(name)}\\s*\\*?$`, 'i');
    const candidates = [
      page.getByRole('textbox', { name: pattern }),
      page.getByLabel(pattern),
    ];

    for (const locator of candidates) {
      if (await locator.count().catch(() => 0)) {
        const target = locator.first();
        if (await target.isVisible().catch(() => false)) {
          await fillText(target, value);
          return true;
        }
      }
    }
  }

  return false;
}

export async function fillFirstDateField(page, value) {
  return fillFirstText(page, ['DOB', 'Date of Birth', 'Birth Date'], value)
    || fillByNearbyText(page, 'Date', value);
}

export async function fillByNearbyText(page, labelText, value) {
  const match = await findFieldByNearbyText(page, labelText, ['INPUT', 'TEXTAREA']);
  if (!match) return false;

  const locator = page.locator(match.selector).nth(match.index);
  await fillText(locator, value);
  return true;
}

export async function selectFirst(page, names, value) {
  for (const name of names) {
    const pattern = name instanceof RegExp ? name : new RegExp(`^${escapeRegex(name)}\\s*\\*?$`, 'i');
    const candidates = [
      page.getByLabel(pattern),
      page.getByRole('combobox', { name: pattern }),
    ];

    for (const locator of candidates) {
      if (await locator.count().catch(() => 0)) {
        const target = locator.first();
        if (await target.isVisible().catch(() => false)) {
          await target.selectOption(String(value));
          return true;
        }
      }
    }
  }

  return false;
}

export async function selectRandomByNearbyText(page, labelText) {
  const match = await findFieldByNearbyText(page, labelText, ['SELECT']);
  if (!match) return false;

  const select = page.locator('select').nth(match.index);
  const values = await select.evaluate((el) => Array.from(el.options)
    .filter((option) => !option.disabled && option.value && !/^--|choose|select/i.test(option.textContent.trim()))
    .map((option) => option.value));

  if (values.length === 0) return false;

  await select.selectOption(pick(values));
  return true;
}

export async function selectRandomCounty(page) {
  const countyLocators = [
    page.getByLabel(/^County\s*\*?$/i),
    page.getByRole('combobox', { name: /^County\s*\*?$/i }),
  ];

  for (const locator of countyLocators) {
    if (await locator.count().catch(() => 0)) {
      const target = locator.first();
      if (await target.isVisible().catch(() => false)) {
        const values = await target.evaluate((el) => Array.from(el.options)
          .filter((option) => !option.disabled && option.value && !/^--|choose|select/i.test(option.textContent.trim()))
          .map((option) => option.value));

        if (values.length) {
          const selectedValue = pick(values);
          await target.selectOption(selectedValue);
          await waitForPageReady(page);

          const currentValue = await target.inputValue().catch(() => '');
          if (currentValue !== selectedValue) {
            await target.selectOption(selectedValue);
            await waitForPageReady(page);
          }

          return true;
        }
      }
    }
  }

  return selectRandomByNearbyText(page, 'County');
}

export async function ensureCountySelected(page) {
  const county = page.getByLabel(/^County\s*\*?$/i)
    .or(page.getByRole('combobox', { name: /^County\s*\*?$/i }))
    .first();

  if (!(await county.count().catch(() => 0)) || !(await county.isVisible().catch(() => false))) {
    return false;
  }

  const value = await county.inputValue().catch(() => '');
  if (value) return true;

  return selectRandomCounty(page);
}

export async function selectStateIfPresent(page, stateValue = 'TX') {
  const selected = await selectFirst(page, ['State', 'State/Province'], stateValue);
  if (selected) await waitForPageReady(page);
  return selected;
}

export async function fillCommonRegistrationFields(page, user) {
  await fillFirstText(page, ['First Name', 'Given Name'], user.firstName);
  await fillFirstText(page, ['Last Name', 'Surname'], user.lastName);
  await fillFirstText(page, ['Program Name', 'Entity Name', 'Business Name', 'Company Name', 'Organization Name', 'Firm Name', 'Legal Name'], user.entityName);
  await fillFirstText(page, ['Email ID', 'Email', 'E-mail', 'Primary E-mail'], user.email);
  await fillFirstText(page, ['Alt Email', 'Alternate E-mail', 'Alternate Email'], user.altEmail);
  await fillFirstText(page, ['Address', 'Street One', 'Street 1', 'Address Line 1'], user.streetOne);
  await fillFirstText(page, ['Street Two', 'Street 2', 'Address Line 2', 'Suite/Apt/Unit/etc.'], user.streetTwo);
  await fillFirstText(page, ['City'], user.city);
  await selectStateIfPresent(page, user.state);
  const zipFilled = await fillFirstText(page, ['Zip', 'Zip Code', 'Postal Code'], user.zip);
  if (zipFilled) {
    await page.keyboard.press('Tab').catch(() => {});
    await waitForPageReady(page);
  }
  await selectRandomCounty(page);
  await fillFirstText(page, [/^Phone(?! Ext)/i, 'Primary Phone', 'Primary Phone #'], user.phone);
  await fillFirstText(page, ['Fax'], user.fax);
  await fillFirstDateField(page, user.date);
  await ensureCountySelected(page);
}

export async function fillAccountFields(page, user) {
  await fillFirstText(page, ['Login Name'], user.loginName);
  await fillFirstText(page, [/^Password$/i, /^Password\s*\*/i], user.password);
  await fillFirstText(page, ['Re-type Password', 'Re-type Password *', 'Confirm Password'], user.password);
}

export async function submitRegistration(page) {
  const linkOrButton = page.getByRole('link', { name: /^Register$/i })
    .or(page.getByRole('button', { name: /^Register$/i }))
    .or(page.getByRole('link', { name: /^Submit$/i }))
    .or(page.getByRole('button', { name: /^Submit$/i }));

  await clickAndWait(page, linkOrButton.first());
}

export async function assertRegistrationSucceeded(page) {
  await waitForPageReady(page);
  await page.waitForTimeout(1000);

  const bodyText = await page.locator('body').innerText().catch(() => '');
  if (await isRegistrationFormOpen(page, bodyText)) {
    throw new Error('Registration did not complete: the page stayed on the initial registration form after clicking Register.');
  }

  if (!/Welcome|Logout|Dashboard|Application for New|Application Preliminary/i.test(bodyText)
    && !/\/Protected\/|\/Dashboard/i.test(page.url())) {
    throw new Error(`Registration did not reach a logged-in/success page. Current URL: ${page.url()}`);
  }
}

export async function getVisibleValidationText(page) {
  const validationText = await page
    .locator('li, .validation-summary-errors, .field-validation-error, [id*="ValidationSummary"], [id*="valSummary"]')
    .evaluateAll((elements) => elements.map((element) => element.textContent ?? '').join('\n'))
    .catch(() => '');

  return validationText
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => /required|invalid|does not match|already|unique|taken|must select|please enter/i.test(line))
    .filter((line) => !/Fields marked|Password is case sensitive/i.test(line))
    .join(' ');
}

export async function getDuplicateProfileText(page) {
  const bodyText = await page.locator('body').innerText().catch(() => '');
  const bodyHtml = await page.locator('body').evaluate((element) => element.innerHTML).catch(() => '');
  const combined = `${bodyText}\n${bodyHtml}`;

  return isDuplicateProfileMessage(combined)
    ? 'Profile with this data already exists.'
    : '';
}

export async function isRegistrationFormOpen(page, knownBodyText) {
  const bodyText = knownBodyText ?? await page.locator('body').innerText().catch(() => '');
  const registerLinkOrButton = page.getByRole('link', { name: /^Register$/i })
    .or(page.getByRole('button', { name: /^Register$/i }))
    .first();

  return /Initial User Registration|User Registration/i.test(bodyText)
    && await registerLinkOrButton.isVisible().catch(() => false);
}

export async function isDuplicateLoginVisible(page) {
  const bodyText = await page.locator('body').innerText().catch(() => '');
  return /login name.*(already|exists|unique|taken)|already.*login name/i.test(bodyText);
}

export function nextDifferentLoginName(product, previousLoginName) {
  return nextLoginNameForAttempt(product, previousLoginName, 1);
}

export function nextLoginNameForAttempt(product, previousLoginName, attemptIndex) {
  const digitLengthIndex = Math.max(0, attemptIndex - 1);
  const digitLength = LOGIN_DIGIT_LENGTHS[Math.min(digitLengthIndex, LOGIN_DIGIT_LENGTHS.length - 1)];
  let nextLoginName;
  do {
    nextLoginName = buildLoginName(product, digitLength);
  } while (nextLoginName === previousLoginName);

  return nextLoginName;
}

export function isDuplicateProfileMessage(message) {
  return /profile with this data already exists|another profile cannot be created|data already exists/i.test(message);
}

async function findFieldByNearbyText(page, labelText, tagNames) {
  return page.evaluate(({ labelText: text, tagNames: tags }) => {
    const wanted = text.toLowerCase();
    const elements = Array.from(document.querySelectorAll(tags.map((tag) => tag.toLowerCase()).join(',')));
    const visibleElements = elements.filter((el) => {
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      return (rect.width || rect.height)
        && style.display !== 'none'
        && style.visibility !== 'hidden'
        && !el.disabled
        && !el.readOnly;
    });

    const element = visibleElements.find((el) => {
      const rowText = (el.closest('tr')?.innerText || el.parentElement?.innerText || '').toLowerCase();
      return rowText.includes(wanted);
    });

    if (!element) return null;

    const sameTagElements = Array.from(document.querySelectorAll(element.tagName.toLowerCase()));
    return {
      selector: element.tagName.toLowerCase(),
      index: sameTagElements.indexOf(element),
    };
  }, { labelText, tagNames });
}

function escapeRegex(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function buildSimpleName(previousUser) {
  const usedNameKeys = previousUser?.usedNameKeys ?? [];
  const used = new Set(usedNameKeys);
  const allNames = FIRST_NAMES.flatMap((firstName) => LAST_NAMES.map((lastName) => ({
    firstName,
    lastName,
    key: `${firstName} ${lastName}`,
  })));
  const availableNames = allNames.filter((name) => !used.has(name.key));
  const chosenName = pick(availableNames.length ? availableNames : allNames);

  if (previousUser) {
    previousUser.usedNameKeys = [...usedNameKeys, chosenName.key];
  }

  return {
    firstName: chosenName.firstName,
    lastName: chosenName.lastName,
  };
}

function randomNumberWithDigitLength(length) {
  if (length <= 1) {
    return String(Math.floor(Math.random() * 9) + 1);
  }

  const min = 10 ** (length - 1);
  const max = (10 ** length) - 1;
  return String(Math.floor(Math.random() * (max - min + 1)) + min);
}
