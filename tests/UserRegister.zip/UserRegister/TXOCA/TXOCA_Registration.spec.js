import { expect, test } from '@playwright/test';
import {
  LOGIN_URL,
  PRODUCT_CONFIGS,
  assertRegistrationSucceeded,
  buildUser,
  clickAndWait,
  fillAccountFields,
  fillCommonRegistrationFields,
  getDuplicateProfileText,
  getVisibleValidationText,
  isDuplicateLoginVisible,
  isDuplicateProfileMessage,
  isRegistrationFormOpen,
  nextLoginNameForAttempt,
  refreshSimpleProfileData,
  saveRegisteredUser,
  submitRegistration,
  waitForPageReady,
} from './TXOCA_Register_Helpers.js';

async function openProductRegistration(page, product) {
  await page.goto(LOGIN_URL, { waitUntil: 'domcontentloaded' });
  await expect(page.getByRole('row', { name: /USER LOGIN\s+Login Name/ }).first()).toBeVisible();
  await clickAndWait(page, page.getByText(product.tabText, { exact: true }));
  await clickAndWait(page, page.locator(`#${product.registrationLinkId}`));
  await expect(page.locator('body')).toContainText(/Initial User Registration|Registration|Online Account|Login Name/i);
}

async function submitWithUniqueLogin(page, product, user, dialogMessages) {
  let loginRetryCount = 0;

  for (let attempt = 1; attempt <= 60; attempt++) {
    await fillAccountFields(page, user);
    await submitRegistration(page);

    const dialogs = dialogMessages.splice(0);
    const duplicateLoginDialog = dialogs.find((message) => /login name.*(already|exists|unique|taken)|already.*login name/i.test(message));
    if (duplicateLoginDialog) {
      loginRetryCount += 1;
      const previousLoginName = user.loginName;
      user.loginName = nextLoginNameForAttempt(product, previousLoginName, loginRetryCount);
      console.warn(`Login name already taken. Retrying ${previousLoginName} -> ${user.loginName}`);
      continue;
    }

    const duplicateProfileDialog = dialogs.find(isDuplicateProfileMessage);
    if (duplicateProfileDialog) {
      await retryWithFreshProfile(page, product, user, duplicateProfileDialog);
      continue;
    }

    if (dialogs.length) {
      throw new Error(`Registration failed alert: ${dialogs.join(' | ')}`);
    }

    if (await isDuplicateLoginVisible(page)) {
      loginRetryCount += 1;
      const previousLoginName = user.loginName;
      user.loginName = nextLoginNameForAttempt(product, previousLoginName, loginRetryCount);
      console.warn(`Login name already taken. Retrying ${previousLoginName} -> ${user.loginName}`);
      continue;
    }

    const duplicateProfileText = await getDuplicateProfileText(page);
    if (duplicateProfileText) {
      await retryWithFreshProfile(page, product, user, duplicateProfileText);
      continue;
    }

    const validationText = await getVisibleValidationText(page);
    if (validationText) {
      throw new Error(`Registration failed validation: ${validationText}`);
    }

    if (await isRegistrationFormOpen(page)) {
      await retryWithFreshProfile(page, product, user, 'Registration form stayed open after submit.');
      continue;
    }

    await assertRegistrationSucceeded(page);
    return user;
  }

  throw new Error('Registration failed: duplicate login/profile message was still shown after 60 attempts.');
}

async function retryWithFreshProfile(page, product, user, reason) {
  const previousName = user.fullName;
  refreshSimpleProfileData(product, user);
  console.warn(`Profile retry (${reason}) ${previousName} -> ${user.fullName}, keeping login ${user.loginName}`);
  await waitForPageReady(page);
  await fillCommonRegistrationFields(page, user);
}

async function registerProduct(page, product, testInfo) {
  const user = buildUser(product);
  const dialogMessages = [];

  page.on('dialog', async (dialog) => {
    dialogMessages.push(dialog.message());
    await dialog.accept().catch(() => {});
  });

  testInfo.annotations.push({ type: 'Product', description: product.productName });
  testInfo.annotations.push({ type: 'Abbreviation', description: product.abbreviation });
  testInfo.annotations.push({ type: 'Login Name', description: user.loginName });
  testInfo.annotations.push({ type: 'Date', description: user.date });
  testInfo.annotations.push({ type: 'Email', description: user.email });

  console.log(`\n-- TXOCA-${product.abbreviation} Registration --------------------------`);
  console.log('Product   :', product.productName);
  console.log('Login Name:', user.loginName);
  console.log('Date      :', user.date);
  console.log('---------------------------------------------------------------');

  await openProductRegistration(page, product);
  await waitForPageReady(page);
  await fillCommonRegistrationFields(page, user);

  const registeredUser = await submitWithUniqueLogin(page, product, user, dialogMessages);
  const userDataPath = saveRegisteredUser(registeredUser);
  console.log(`Credentials saved -> ${userDataPath}`);
}

test.describe('TXOCA User Registration', () => {
  for (const product of PRODUCT_CONFIGS) {
    test(`Register ${product.productName} @${product.abbreviation}`, async ({ page }, testInfo) => {
      await registerProduct(page, product, testInfo);
    });
  }
});
