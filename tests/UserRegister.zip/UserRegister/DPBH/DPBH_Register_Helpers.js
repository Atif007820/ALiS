import { mkdirSync, writeFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { faker } from '@faker-js/faker';

const currentFile = fileURLToPath(import.meta.url);
const testsRoot = dirname(dirname(currentFile));

export const LOGIN_URL = 'http://172.16.3.2/ALiSDPBH2TESTING11.4.37.03/login.aspx';
export const DEFAULT_PASSWORD = 'Password@1';
export const PRIMARY_EMAIL = 'mohdatif.jamal@ops1.advancedgrc.com';
export const ALT_EMAIL = 'mohdatif.jamal@ops1.advancedgrc.com';
export const USER_DATA_DIR = join(testsRoot, 'testData');

export const PRODUCT_CONFIGS = [
  {
    abbreviation: 'HF',
    productName: 'Health Facility',
    sectionText: 'HCQC',
    registrationLinkId: 'm_LoginControl_LinkButton11',
    loginPrefix: 'HCQC_HF_',
    formType: 'facility',
    entityPrefix: 'HCQC_HF',
  },
  {
    abbreviation: 'DL',
    productName: 'Dietician License',
    sectionText: 'HCQC',
    registrationLinkId: 'm_LoginControl_LinkButton6',
    loginPrefix: 'HCQC_DL_',
    formType: 'person',
    entityPrefix: 'HCQC_DL',
  },
  {
    abbreviation: 'MTL',
    productName: 'Music Therapist License',
    sectionText: 'HCQC',
    registrationLinkId: 'm_LoginControl_LinkButton7',
    loginPrefix: 'HCQC_MTL_',
    formType: 'person',
    entityPrefix: 'HCQC_MTL',
  },
  {
    abbreviation: 'MLL',
    productName: 'Medical Laboratory License',
    sectionText: 'HCQC',
    registrationLinkId: 'm_LoginControl_LinkButton2',
    loginPrefix: 'HCQC_MLL_',
    formType: 'facility',
    entityPrefix: 'HCQC_MLL',
  },
  {
    abbreviation: 'CCFL',
    productName: 'Child Care Facility License',
    tabSelector: '[id="__tab_Test_TabPanel2"]',
    registrationLinkId: 'm_LoginControl_lnkInitialChildCare',
    loginPrefix: 'CCFL_',
    formType: 'facility',
    entityPrefix: 'CCFL',
  },
  {
    abbreviation: 'CCFD',
    productName: 'Child Care Facility Director',
    tabSelector: '[id="__tab_Test_TabPanel2"]',
    registrationLinkId: 'm_LoginControl_lnkChildCaredirector',
    loginPrefix: 'CCFD_',
    formType: 'person',
    entityPrefix: 'CCFD',
  },
  {
    abbreviation: 'CBA',
    productName: 'Common Business Application',
    tabSelector: '[id="__tab_Test_TabPanel"]',
    registrationLinkId: 'm_LoginControl_lnkFoodEstablishmentPermit',
    loginPrefix: 'EH_CBA_',
    formType: 'facility',
    entityPrefix: 'EH_CBA',
  },
  {
    abbreviation: 'TP',
    productName: 'Temporary Permit',
    tabSelector: '[id="__tab_Test_TabPanel"]',
    registrationLinkId: 'm_LoginControl_lnkTemporaryFoodPermit',
    loginPrefix: 'EH_TP_',
    formType: 'facility',
    entityPrefix: 'EH_TP',
  },
];

const FIRST_NAMES = [
  'John', 'Mike', 'David', 'James', 'Robert',
  'Chris', 'Mark', 'Paul', 'Steve', 'Kevin',
  'Brian', 'Adam', 'Eric', 'Ryan', 'Jason',
  'Mary', 'Linda', 'Susan', 'Karen', 'Lisa',
  'Sarah', 'Nancy', 'Laura', 'Amy', 'Emma',
];
const LAST_NAMES = [
  'Smith', 'Brown', 'Davis', 'Wilson', 'Taylor',
  'Moore', 'Clark', 'Hall', 'White', 'Green',
  'Baker', 'King', 'Lee', 'Hill', 'Young',
];
const CITIES = ['Las Vegas', 'Reno', 'Henderson', 'Sparks', 'Carson City', 'Elko'];
const STREET_NAMES = ['Main', 'Market', 'Broad', 'State', 'Center', 'Park'];
const LOGIN_DIGIT_LENGTHS = [1, 2, 3, 5, 6, 7, 8];

export const pick = (items) => faker.helpers.arrayElement(items);
export const randDigits = (length) => Array.from({ length }, () => Math.floor(Math.random() * 10)).join('');
export const randomPhone = () => `${randDigits(3)}-${randDigits(3)}-${randDigits(4)}`;
export const randomZip = () => `${randomNumberWithDigitLength(5)}-${randDigits(4)}`;
export const randomStreet = () => `${randomNumberWithDigitLength(3)} ${pick(STREET_NAMES)} Street`;
export const randomUnit = () => `${pick(['Suite', 'Apt', 'Unit'])} ${randomNumberWithDigitLength(2)}`;
export const randomCity = () => pick(CITIES);

export function currentDateParts() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, '0');
  const hours24 = now.getHours();
  const hours12 = hours24 % 12 || 12;
  const ampm = hours24 >= 12 ? 'PM' : 'AM';

  return {
    dateForName: `${pad(now.getDate())}-${pad(now.getMonth() + 1)}-${now.getFullYear()}`,
    dateForField: `${pad(now.getMonth() + 1)}/${pad(now.getDate())}/${now.getFullYear()}`,
    timeForName: `${pad(hours12)}:${pad(now.getMinutes())}:${pad(now.getSeconds())} ${ampm}`,
  };
}

export function buildEntityName(prefix) {
  const { dateForName, timeForName } = currentDateParts();
  return `${prefix}_${dateForName}_${timeForName}`;
}

export function buildLoginName(product, digitLength = 1) {
  return `${product.loginPrefix}${randomNumberWithDigitLength(digitLength)}`;
}

export function buildUser(product) {
  const firstName = pick(FIRST_NAMES);
  const lastName = pick(LAST_NAMES);
  const { dateForField } = currentDateParts();

  return {
    product: product.abbreviation,
    productName: product.productName,
    formType: product.formType,
    firstName,
    lastName,
    contactPerson: `${firstName} ${lastName}`,
    facilityName: buildEntityName(product.entityPrefix),
    nvBusinessId: `NV${randomNumberWithDigitLength(11)}`,
    ssnTin: randomSsn(),
    dob: dateForField,
    streetOne: randomStreet(),
    streetTwo: randomUnit(),
    city: randomCity(),
    zip: randomZip(),
    phone: randomPhone(),
    fax: randomPhone(),
    email: PRIMARY_EMAIL,
    altEmail: ALT_EMAIL,
    loginName: buildLoginName(product),
    password: DEFAULT_PASSWORD,
  };
}

export function refreshProfileData(product, user) {
  user.firstName = pick(FIRST_NAMES);
  user.lastName = pick(LAST_NAMES);
  user.contactPerson = `${user.firstName} ${user.lastName}`;
  user.facilityName = buildEntityName(product.entityPrefix);
  user.nvBusinessId = `NV${randomNumberWithDigitLength(11)}`;
  user.ssnTin = randomSsn();
  user.streetOne = randomStreet();
  user.streetTwo = randomUnit();
  user.city = randomCity();
  user.zip = randomZip();
  user.phone = randomPhone();
  user.fax = randomPhone();
  user.email = PRIMARY_EMAIL;
  user.altEmail = ALT_EMAIL;

  return user;
}

export function saveRegisteredUser(user) {
  const filePath = join(USER_DATA_DIR, `lastRegisteredDPBH${user.product}User.json`);
  mkdirSync(dirname(filePath), { recursive: true });
  writeFileSync(filePath, `${JSON.stringify(user, null, 2)}\n`, 'utf-8');
  return filePath;
}

export async function waitForPageReady(page) {
  await page.waitForLoadState('domcontentloaded').catch(() => {});
  await page.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
  await waitForAspNetIdle(page);
}

export async function dismissOptionalStartupDialog(page) {
  await waitForPageReady(page);

  const noticeLink = page.getByRole('link', { name: /dpbh\.nv\.gov\/Reg\/CLICS/i }).first();
  const doNotShowCheckbox = page.getByRole('checkbox', { name: /Please do not show this/i }).first();
  const noticeVisible = await noticeLink.isVisible({ timeout: 1500 }).catch(() => false)
    || await doNotShowCheckbox.isVisible({ timeout: 1500 }).catch(() => false);

  if (!noticeVisible) {
    return false;
  }

  if (await doNotShowCheckbox.isVisible().catch(() => false)) {
    await doNotShowCheckbox.check().catch(() => {});
  }

  await page.goto(LOGIN_URL.replace('/login.aspx', '/Login.aspx'), { waitUntil: 'domcontentloaded' });
  await waitForPageReady(page);
  return true;
}

export async function waitForAspNetIdle(page) {
  await page.evaluate(() => new Promise((resolve) => {
    const mgr = window.Sys?.WebForms?.PageRequestManager?.getInstance?.();
    if (!mgr || !mgr.get_isInAsyncPostBack()) {
      resolve();
      return;
    }

    const interval = setInterval(() => {
      if (!mgr.get_isInAsyncPostBack()) {
        clearInterval(interval);
        resolve();
      }
    }, 50);

    setTimeout(() => {
      clearInterval(interval);
      resolve();
    }, 15000);
  })).catch(() => {});

  await page.waitForTimeout(300);
}

export async function clickAndWait(page, locator) {
  await locator.scrollIntoViewIfNeeded().catch(() => {});
  await locator.click({ noWaitAfter: true });
  await waitForPageReady(page);
}

export async function firstVisibleText(page, text) {
  for (const locator of [
    page.getByText(text, { exact: true }),
    page.getByText(text, { exact: false }),
  ]) {
    const count = await locator.count().catch(() => 0);
    for (let index = 0; index < count; index++) {
      const candidate = locator.nth(index);
      if (await candidate.isVisible().catch(() => false)) {
        return candidate;
      }
    }
  }

  return page.getByText(text, { exact: false }).first();
}

export async function fillText(locator, value) {
  const { expect } = await import('@playwright/test');
  const target = locator.first();
  await expect(target).toBeVisible();
  await expect(target).toBeEnabled();
  await target.scrollIntoViewIfNeeded().catch(() => {});
  await target.fill(String(value));
}

export async function fillFirstText(page, names, value) {
  for (const name of names) {
    const pattern = name instanceof RegExp ? name : new RegExp(`^${escapeRegex(name)}\\s*\\*?$`, 'i');
    const candidates = [
      page.getByRole('textbox', { name: pattern }),
      page.getByLabel(pattern),
    ];

    for (const locator of candidates) {
      if (await locator.count().catch(() => 0)) {
        const target = locator.first();
        if (await target.isVisible().catch(() => false)) {
          await fillText(target, value);
          return true;
        }
      }
    }
  }

  return false;
}

export async function fillDateOfBirth(page, user) {
  const dateFields = [
    page.getByRole('textbox', { name: /DOB/i }),
    page.getByLabel(/DOB/i),
    page.getByRole('textbox', { name: /Date of Birth/i }),
    page.getByLabel(/Date of Birth/i),
  ];

  for (const locator of dateFields) {
    if (await locator.count().catch(() => 0)) {
      const target = locator.first();
      if (await target.isVisible().catch(() => false)) {
        await target.scrollIntoViewIfNeeded().catch(() => {});
        const filled = await target.fill(user.dob).then(() => true).catch(() => false);
        if (filled) return true;
      }
    }
  }

  const calendarButton = page.getByRole('button', { name: /CalenderImage|Calendar/i }).first();
  if (!(await calendarButton.count().catch(() => 0)) || !(await calendarButton.isVisible().catch(() => false))) {
    return false;
  }

  const popupPromise = page.waitForEvent('popup', { timeout: 8000 }).catch(() => null);
  await calendarButton.click({ noWaitAfter: true });
  const popup = await popupPromise;

  if (popup) {
    await popup.getByRole('button', { name: /^OK$/i }).click({ timeout: 10000 }).catch(async () => {
      await popup.locator('input[type="submit"], button').last().click();
    });
    await popup.close().catch(() => {});
    await waitForPageReady(page);
    return true;
  }

  await waitForPageReady(page);
  return true;
}

export async function selectRandomCounty(page) {
  const county = page.getByLabel(/^County\s*\*?$/i)
    .or(page.getByRole('combobox', { name: /^County\s*\*?$/i }))
    .first();

  if (!(await county.count().catch(() => 0)) || !(await county.isVisible().catch(() => false))) {
    return false;
  }

  await selectPreferredOrRandom(county);
  await waitForPageReady(page);
  return true;
}

export async function fillFacilityRegistrationFields(page, user) {
  await fillFirstText(page, ['Facility Name (DBA Name)', 'Facility Name'], user.facilityName);
  await fillFirstText(page, [/Registered Name with/i, /Registered Name/i], user.facilityName);
  await fillFirstText(page, ['NV Business ID'], user.nvBusinessId);
  await fillCommonContactFields(page, user);
}

export async function fillPersonRegistrationFields(page, user) {
  await fillFirstText(page, ['Last Name'], user.lastName);
  await fillFirstText(page, ['First Name'], user.firstName);
  await fillDateOfBirth(page, user);
  await fillFirstText(page, ['SSN/TIN', 'SSN', 'TIN'], user.ssnTin);
  await fillCommonContactFields(page, user);
}

export async function fillCommonContactFields(page, user) {
  await fillFirstText(page, ['Contact Person'], user.contactPerson);
  await fillFirstText(page, ['Street One', 'Street 1', 'Address Line 1'], user.streetOne);
  await fillFirstText(page, ['Street Two', 'Street 2', 'Address Line 2'], user.streetTwo);
  await fillFirstText(page, ['City'], user.city);

  const zipFilled = await fillFirstText(page, ['Zip', 'Zip Code'], user.zip);
  if (zipFilled) {
    await page.keyboard.press('Tab').catch(() => {});
    await waitForPageReady(page);
  }

  await selectRandomCounty(page);
  await fillFirstText(page, [/^Phone(?! Ext)/i], user.phone);
  await fillFirstText(page, ['Fax'], user.fax);
  await fillFirstText(page, ['Email'], user.email);
  await fillFirstText(page, ['Alt Email', 'Alternate Email'], user.altEmail);
}

export async function fillAccountFields(page, user) {
  await fillFirstText(page, ['Login Name'], user.loginName);
  await fillFirstText(page, [/^Password\s*\*?$/i], user.password);
  await fillFirstText(page, ['Re-type Password', 'Confirm Password'], user.password);
}

export async function submitRegistration(page) {
  const register = page.getByRole('link', { name: /^Register$/i })
    .or(page.getByRole('button', { name: /^Register$/i }))
    .first();

  await clickAndWait(page, register);
}

export async function getVisibleValidationText(page) {
  const validationText = await page
    .locator('li, .validation-summary-errors, .field-validation-error, [id*="ValidationSummary"], [id*="valSummary"], [id*="RequiredFieldValidator"], [id*="RegularExpressionValidator"]')
    .evaluateAll((elements) => elements.map((element) => element.textContent ?? '').join('\n'))
    .catch(() => '');

  return validationText
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => /required|invalid|does not match|already|unique|taken|must select|please enter/i.test(line))
    .filter((line) => !/Fields marked|Password is case sensitive/i.test(line))
    .join(' ');
}

export async function isDuplicateLoginVisible(page) {
  const bodyText = await page.locator('body').innerText().catch(() => '');
  return /login name.*(already|exists|unique|taken)|already.*login name/i.test(bodyText);
}

export async function getDuplicateProfileText(page) {
  const bodyText = await page.locator('body').innerText().catch(() => '');
  const bodyHtml = await page.locator('body').evaluate((element) => element.innerHTML).catch(() => '');
  const combined = `${bodyText}\n${bodyHtml}`;

  return /profile with this data already exists|another profile cannot be created|data already exists/i.test(combined)
    ? 'Profile with this data already exists.'
    : '';
}

export async function isRegistrationFormOpen(page) {
  const register = page.getByRole('link', { name: /^Register$/i })
    .or(page.getByRole('button', { name: /^Register$/i }))
    .first();
  const loginName = page.getByRole('textbox', { name: /Login Name\s*\*/i }).first();

  return await register.isVisible().catch(() => false)
    && await loginName.isVisible().catch(() => false);
}

export function nextLoginNameForAttempt(product, previousLoginName, attemptIndex) {
  const digitLengthIndex = Math.max(0, attemptIndex - 1);
  const digitLength = LOGIN_DIGIT_LENGTHS[Math.min(digitLengthIndex, LOGIN_DIGIT_LENGTHS.length - 1)];
  let nextLoginName;

  do {
    nextLoginName = buildLoginName(product, digitLength);
  } while (nextLoginName === previousLoginName);

  return nextLoginName;
}

async function selectPreferredOrRandom(locator) {
  const options = await locator.evaluate((select) => Array.from(select.options)
    .filter((option) => !option.disabled && option.value && !/^--|choose|select/i.test(option.textContent.trim()))
    .map((option) => option.value));

  if (!options.length) {
    return false;
  }

  await locator.selectOption(pick(options));
  return true;
}

function randomNumberWithDigitLength(length) {
  if (length <= 1) {
    return String(Math.floor(Math.random() * 9) + 1);
  }

  const min = 10 ** (length - 1);
  const max = (10 ** length) - 1;
  return String(Math.floor(Math.random() * (max - min + 1)) + min);
}

function randomSsn() {
  const area = Math.floor(Math.random() * (665 - 200 + 1)) + 200;
  const group = String(Math.floor(Math.random() * 99) + 1).padStart(2, '0');
  const serial = String(Math.floor(Math.random() * 9999) + 1).padStart(4, '0');
  return `${area}-${group}-${serial}`;
}

function escapeRegex(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
