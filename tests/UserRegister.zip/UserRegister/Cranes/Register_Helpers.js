import { join } from 'path';
import { writeFileSync } from 'fs';

export const USER_DATA_PATH = join(process.cwd(), 'userData.json');

export function saveUserData({ loginName, password, firstName, lastName, entityName }) {
  writeFileSync(
    USER_DATA_PATH,
    JSON.stringify({ loginName, password, firstName, lastName, entityName }, null, 2),
    'utf-8'
  );
}

export const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
export const randDigits = (n) => Array.from({ length: n }, () => Math.floor(Math.random() * 10)).join('');
export const randAlpha = (n) => Array.from(
  { length: n },
  () => String.fromCharCode(65 + Math.floor(Math.random() * 26))
).join('');

export const randomPhone = () => `${randDigits(3)}-${randDigits(3)}-${randDigits(4)}`;
export const randomUBI = () => `${randDigits(3)}-${randDigits(3)}-${randDigits(3)}`;
export const randomZip = () => `${randDigits(5)}-${randDigits(4)}`;
export const randomGCL = () => `GCL${randDigits(4)}`;
export const randomCraneOwnerId = () => `CRNOWN${randDigits(4)}`;
export const randomLoginName = () => `${pick(SIMPLE_ENGLISH_NAMES)}${Math.floor(Math.random() * 9999) + 1}`;

export const randomAddress = (city) => {
  const buildingNumber = randDigits(3);
  const buildingType = pick(['Apartments', 'Building']);
  return Math.random() > 0.5
    ? `${buildingNumber} ${buildingType}, ${city} Street`
    : `${buildingNumber} ${buildingType}, ${city}`;
};

export const randomUnit = () => {
  const prefix = pick(['Suite', 'Apt', 'Unit']);
  const variant = Math.floor(Math.random() * 3);
  if (variant === 0) return `${prefix} - ${randDigits(1)}/${randAlpha(1)}`;
  if (variant === 1) return `${prefix} - ${randDigits(2)}/${randAlpha(1)}`;
  return `${prefix} - ${randAlpha(1)}`;
};

export function getNowFormatted() {
  const now = new Date();

  const dd = String(now.getDate()).padStart(2, '0');
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const yyyy = String(now.getFullYear());

  let hours = now.getHours();
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12 || 12;

  const HH = String(hours).padStart(2, '0');
  const MM = String(now.getMinutes()).padStart(2, '0');
  const SS = String(now.getSeconds()).padStart(2, '0');

  return {
    currentDate: `${dd}-${mm}-${yyyy}`,
    currentTime: `${HH}:${MM}:${SS} ${ampm}`,
  };
}

export const clearTextInputs = async (page) => {
  await page
    .locator('input[type="text"], input[type="email"], input[type="tel"], input[type="password"], textarea, select')
    .evaluateAll((elements) => {
      elements.forEach((el) => {
        if (!el.readOnly && !el.disabled) {
          if (el.tagName === 'SELECT') {
            el.selectedIndex = -1;
            el.value = '';
          } else {
            el.value = '';
          }
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
        }
      });
    });
};

export const fillText = async (locator, value) => {
  const { expect } = await import('@playwright/test');
  await expect(locator).toBeVisible();
  await expect(locator).toBeEnabled();
  await locator.focus();
  await locator.evaluate((el) => {
    if (!el.readOnly && !el.disabled) {
      el.value = '';
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
  });
  await locator.fill('');
  await locator.fill(value);
};

export const safeSelect = async (locator, value) => {
  const { expect } = await import('@playwright/test');
  await expect(locator).toBeVisible();
  await expect(locator).toBeEnabled();
  await locator.selectOption(value);
};

export const selectRandomVisibleOption = async (locator) => {
  if (await locator.count() === 0) return false;

  const select = locator.first();
  if (!await select.isVisible().catch(() => false)) return false;
  if (!await select.isEnabled().catch(() => false)) return false;

  const values = await select.evaluate((el) => Array.from(el.options)
    .filter((option) => !option.disabled && option.value && !option.textContent.trim().startsWith('--'))
    .map((option) => option.value));

  if (values.length === 0) return false;

  await select.selectOption(pick(values));
  return true;
};

export const sanitizeLoginPart = (value) => value.replace(/[^A-Za-z0-9]/g, '');

export const LOGIN_URL = 'http://172.16.3.2/ALiSWADLNI2TESTING11.4.35.06.02/LoginCMS.aspx';
export const BUSINESS_UNIT = 'CRN';
export const ROLE_CRANE_CONTRACTOR = 'CRNCNTR';
export const BUSINESS_EMAIL = 'mohdatif.jamal@ops1.advancedgrc.com';
export const ALTERNATE_EMAIL = 'atif.jamaldpsmk@gmail.com';
export const DEFAULT_PASSWORD = 'Password@1';
export const ENTITY_ROLES = ['OWN', 'LPC', 'PRT', 'BDC'];
export const COUNTRIES = ['US'];

export const SIMPLE_ENGLISH_NAMES = [
  'John', 'Mike', 'David', 'James', 'Robert',
  'Chris', 'Mark', 'Paul', 'Steve', 'Kevin',
  'Brian', 'Adam', 'Eric', 'Ryan', 'Jason',
  'Mary', 'Linda', 'Susan', 'Karen', 'Lisa',
  'Sarah', 'Nancy', 'Laura', 'Amy', 'Emma',
];

export const US_STATES = [
  'AL', 'AK', 'AS', 'AZ', 'CA', 'CO', 'CT', 'DE', 'DC', 'FL',
  'FM', 'GA', 'GU', 'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY',
  'LA', 'ME', 'MD', 'MA', 'MH', 'MI', 'MN', 'MS', 'MO', 'MT',
  'NE', 'NV', 'NH', 'NJ', 'NM', 'NY', 'NC', 'ND', 'MP', 'OH',
  'OK', 'OR', 'PA', 'PR', 'RI', 'SC', 'SD', 'TN', 'TX', 'UT',
  'VT', 'VA', 'WV', 'WI', 'WY',
];

export const US_CITIES = [
  'New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix',
  'Philadelphia', 'San Antonio', 'San Diego', 'Dallas', 'San Jose',
  'Austin', 'Jacksonville', 'Fort Worth', 'Columbus', 'Charlotte',
  'San Francisco', 'Indianapolis', 'Seattle', 'Denver', 'Boston',
  'Miami', 'Minneapolis', 'Portland', 'Atlanta', 'Las Vegas',
  'Brooklyn', 'Detroit', 'New Orleans', 'Memphis', 'Nashville',
];
