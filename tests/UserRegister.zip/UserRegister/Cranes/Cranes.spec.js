import { test, expect } from '@playwright/test';
import { faker } from '@faker-js/faker';
import {
  ALTERNATE_EMAIL,
  BUSINESS_EMAIL,
  BUSINESS_UNIT,
  COUNTRIES,
  DEFAULT_PASSWORD,
  LOGIN_URL,
  ROLE_CRANE_CONTRACTOR,
  USER_DATA_PATH,
  US_CITIES,
  US_STATES,
  clearTextInputs,
  fillText,
  getNowFormatted,
  pick,
  randomAddress,
  randomCraneOwnerId,
  randomGCL,
  randomLoginName,
  randomPhone,
  randomUBI,
  randomUnit,
  randomZip,
  safeSelect,
  saveUserData,
  selectRandomVisibleOption,
} from './Register_Helpers.js';

test('01 - Register New LNI Cranes User', async ({ page }, testInfo) => {
  const ubiNumber = randomUBI();
  const gclNumber = randomGCL();
  const craneOwnerId = randomCraneOwnerId();
  const country = pick(COUNTRIES);
  const state = pick(US_STATES.filter((stateCode) => stateCode !== 'WA'));
  const city = pick(US_CITIES);
  const zip = randomZip();
  const businessPhone = randomPhone();
  const primaryPhone = randomPhone();
  const fax = randomPhone();
  const userPhone = randomPhone();

  const { currentDate, currentTime } = getNowFormatted();
  const entityName = `CRN_${currentDate}_${currentTime}`;
  const address = randomAddress(city);
  const subUnit = randomUnit();

  const firstName = faker.person.firstName();
  const lastName = faker.person.lastName();
  let currentLoginName = randomLoginName();
  const password = DEFAULT_PASSWORD;

  testInfo.annotations.push({ type: 'Person', description: `${firstName} ${lastName}` });
  testInfo.annotations.push({ type: 'Login Name', description: currentLoginName });
  testInfo.annotations.push({ type: 'Product', description: 'LNI - Cranes' });
  testInfo.annotations.push({ type: 'Business Unit', description: BUSINESS_UNIT });
  testInfo.annotations.push({ type: 'Role', description: ROLE_CRANE_CONTRACTOR });
  testInfo.annotations.push({ type: 'Entity', description: entityName });

  console.log('\n-- LNI-Cranes Registration --------------------------');
  console.log('Person    :', firstName, lastName);
  console.log('Login Name:', currentLoginName);
  console.log('Entity    :', entityName);
  console.log('GCL       :', gclNumber);
  console.log('Owner ID  :', craneOwnerId);
  console.log('-----------------------------------------------------------');

  await page.addInitScript(() => {
    document.addEventListener('DOMContentLoaded', () => {
      document.querySelectorAll('input, textarea')
        .forEach((el) => el.setAttribute('autocomplete', 'off'));
    });
  });

  await page.goto(LOGIN_URL, { waitUntil: 'networkidle' });
  await expect(page.getByRole('row', { name: /USER LOGIN\s+Login Name/ }).first()).toBeVisible();
  await page.locator('#m_LoginControl_LinkButton2').click();

  await safeSelect(page.getByLabel('Business Unit'), BUSINESS_UNIT);
  await safeSelect(page.getByLabel('Please select your role'), ROLE_CRANE_CONTRACTOR);
  await fillText(page.getByRole('textbox', { name: 'General Contractor License#' }), gclNumber);
  await fillText(page.getByRole('textbox', { name: 'Crane Owner ID' }), craneOwnerId);

  await Promise.all([
    page.getByRole('heading', { name: 'Initial User Registration -' }).waitFor({ state: 'visible' }),
    page.getByRole('button', { name: 'Next' }).click(),
  ]);

  await clearTextInputs(page);

  await fillText(page.getByRole('textbox', { name: 'Entity Name' }), entityName);
  await fillText(page.getByRole('textbox', { name: 'UBI #' }), ubiNumber);
  await fillText(page.locator('#txtFirstNameBE'), 'Atif');
  await fillText(page.locator('#txtLastNameBE'), 'Jamal');
  await fillText(page.locator('#Email'), BUSINESS_EMAIL);
  await fillText(page.locator('#txtPhone'), businessPhone);

  await safeSelect(page.getByLabel('Country'), country);
  await fillText(page.getByRole('textbox', { name: 'Address' }), address);
  await fillText(page.getByRole('textbox', { name: 'Suite/Apt/Unit/etc.' }), subUnit);
  await fillText(page.getByRole('textbox', { name: 'City' }), city);
  await safeSelect(page.getByLabel('State/Province'), state);
  await fillText(page.getByRole('textbox', { name: 'Zip' }), zip);
  await selectRandomVisibleOption(page.getByLabel('County'));
  await fillText(page.getByRole('textbox', { name: 'Primary Phone #', exact: true }), primaryPhone);
  await fillText(page.getByRole('textbox', { name: 'Fax' }), fax);
  await fillText(page.getByRole('textbox', { name: 'Primary E-mail' }), BUSINESS_EMAIL);
  await fillText(page.getByRole('textbox', { name: 'Alternate E-mail' }), ALTERNATE_EMAIL);

  await fillText(page.locator('#txtLastName'), lastName);
  await fillText(page.locator('#txtFirstName'), firstName);
  await fillText(page.getByPlaceholder('E-mail'), BUSINESS_EMAIL);
  await fillText(page.locator('#txtUserPhone'), userPhone);
  await page.getByRole('checkbox', { name: 'I have read and agree to the' }).check();
  await fillText(page.getByRole('textbox', { name: 'Name*', exact: true }), `${firstName} ${lastName}`);

  await fillText(page.getByRole('textbox', { name: 'Login Name*' }), currentLoginName);
  await fillText(page.getByRole('textbox', { name: 'Password*' }), password);
  await fillText(page.getByRole('textbox', { name: 'Re-type Password *' }), password);

  while (true) {
    await page.getByRole('button', { name: 'Register' }).click();

    const successMsg = page.getByText('You have successfully registered.');
    const duplicateError = page.locator("//li[contains(text(),'Login Name must be unique; the login name has alre')]");

    const result = await Promise.any([
      successMsg.waitFor({ state: 'visible', timeout: 30000 }).then(() => 'success'),
      duplicateError.waitFor({ state: 'visible', timeout: 30000 }).then(() => 'duplicate'),
    ]).catch(() => 'timeout');

    if (result === 'success') {
      console.log('Registration successful');
      saveUserData({ loginName: currentLoginName, password, firstName, lastName, entityName });
      console.log(`Credentials saved -> ${USER_DATA_PATH}`);
      break;
    }

    if (result === 'duplicate') {
      const previousLoginName = currentLoginName;
      const previousName = previousLoginName.replace(/\d+$/, '');
      do {
        currentLoginName = randomLoginName();
      } while (
        currentLoginName === previousLoginName ||
        currentLoginName.replace(/\d+$/, '') === previousName
      );
      console.warn(`Login name already taken. Retrying with "${currentLoginName}"`);
      await fillText(page.getByRole('textbox', { name: 'Login Name*' }), currentLoginName);
      continue;
    }

    throw new Error('Registration failed: timed out waiting for success or duplicate-login error.');
  }
});
