import { expect, test } from '@playwright/test';
import {
  LOGIN_URL,
  PRODUCT,
  buildUser,
  clickAndWait,
  fillAccountFields,
  fillProviderRegistrationFields,
  firstVisibleText,
  getDuplicateProfileText,
  getVisibleValidationText,
  isDuplicateLoginVisible,
  isRegistrationFormOpen,
  nextLoginNameForAttempt,
  refreshProfileData,
  saveRegisteredUser,
  submitRegistration,
  waitForPageReady,
} from './SPC_Register_Helpers.js';

async function openProductRegistration(page, product) {
  await page.goto(LOGIN_URL, { waitUntil: 'domcontentloaded' });
  await waitForPageReady(page);

  await clickAndWait(page, await firstVisibleText(page, product.sectionText));
  await clickAndWait(page, page.locator(`#${product.registrationLinkId}`));
  await expect(page.locator('body')).toContainText(/Provider Name|Login Name/i);
}

async function submitWithRetries(page, product, user, dialogMessages) {
  let loginRetryCount = 0;

  for (let attempt = 1; attempt <= 40; attempt += 1) {
    await fillAccountFields(page, user);
    await submitRegistration(page);

    const dialogs = dialogMessages.splice(0);
    const duplicateLoginDialog = dialogs.find((message) => /login name.*(already|exists|unique|taken)|already.*login name/i.test(message));
    if (duplicateLoginDialog || await isDuplicateLoginVisible(page)) {
      loginRetryCount += 1;
      const previousLoginName = user.loginName;
      user.loginName = nextLoginNameForAttempt(product, previousLoginName, loginRetryCount);
      console.warn(`Login name already taken. Retrying ${previousLoginName} -> ${user.loginName}`);
      continue;
    }

    const duplicateProfileDialog = dialogs.find((message) => /profile with this data already exists|another profile cannot be created|data already exists/i.test(message));
    const duplicateProfileText = duplicateProfileDialog || await getDuplicateProfileText(page);
    if (duplicateProfileText) {
      await retryWithFreshProfile(page, product, user, duplicateProfileText);
      continue;
    }

    if (dialogs.length) {
      throw new Error(`Registration failed alert: ${dialogs.join(' | ')}`);
    }

    const validationText = await getVisibleValidationText(page);
    if (validationText) {
      throw new Error(`Registration failed validation: ${validationText}`);
    }

    if (await isRegistrationFormOpen(page)) {
      await retryWithFreshProfile(page, product, user, 'Registration form stayed open after submit.');
      continue;
    }

    return user;
  }

  throw new Error('Registration failed: duplicate login/profile message was still shown after 40 attempts.');
}

async function retryWithFreshProfile(page, product, user, reason) {
  const previousLabel = user.providerName;
  refreshProfileData(product, user);
  console.warn(`Profile retry (${reason}) ${previousLabel} -> ${user.providerName}, keeping login ${user.loginName}`);
  await waitForPageReady(page);
  await fillProviderRegistrationFields(page, user);
}

async function registerProduct(page, product, testInfo) {
  const user = buildUser(product);
  const dialogMessages = [];

  page.on('dialog', async (dialog) => {
    dialogMessages.push(dialog.message());
    await dialog.accept().catch(() => {});
  });

  testInfo.annotations.push({ type: 'Product', description: product.productName });
  testInfo.annotations.push({ type: 'Abbreviation', description: product.abbreviation });
  testInfo.annotations.push({ type: 'Login Name', description: user.loginName });
  testInfo.annotations.push({ type: 'Provider Name', description: user.providerName });
  testInfo.annotations.push({ type: 'Email', description: user.email });

  console.log(`\n-- ${product.abbreviation} Registration --------------------------`);
  console.log('Product      :', product.productName);
  console.log('Provider Name:', user.providerName);
  console.log('Login Name   :', user.loginName);
  console.log('Email        :', user.email);
  console.log('---------------------------------------------------------------');

  await openProductRegistration(page, product);
  dialogMessages.length = 0;
  await fillProviderRegistrationFields(page, user);

  const registeredUser = await submitWithRetries(page, product, user, dialogMessages);
  const userDataPath = saveRegisteredUser(registeredUser);
  console.log(`Credentials saved -> ${userDataPath}`);
}

test.describe('SPC User Registration', () => {
  test(`Register ${PRODUCT.productName} @${PRODUCT.abbreviation}`, async ({ page }, testInfo) => {
    await registerProduct(page, PRODUCT, testInfo);
  });
});
