import { mkdirSync, writeFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { expect } from '@playwright/test';
import { faker } from '@faker-js/faker';

const currentFile = fileURLToPath(import.meta.url);
const testsRoot = dirname(dirname(currentFile));

export const LOGIN_URL = 'http://172.16.3.2/ALiSNVSAPTA2TESTING11.4.38.04/LoginBHCEN.aspx';
export const DEFAULT_PASSWORD = 'Password@1';
export const PRIMARY_EMAIL = 'mohdatif.jamal@ops1.advancedgrc.com';
export const ALT_EMAIL = 'mohdatif.jamal@ops1.advancedgrc.com';
export const USER_DATA_DIR = join(testsRoot, 'testData');

export const PRODUCT = {
  abbreviation: 'DC',
  productName: 'Detoxification Certification',
  sectionText: 'Behavioral Health Certifications for Excellence in Nevada',
  registrationLinkId: 'm_LoginControl_LinkButton10',
  loginPrefix: 'Detox_Cert_',
};

const FIRST_NAMES = [
  'John', 'Mike', 'David', 'James', 'Robert', 'Chris', 'Mark', 'Paul', 'Steve', 'Kevin',
  'Brian', 'Adam', 'Eric', 'Ryan', 'Jason', 'Tom', 'Ben', 'Sam', 'Alex', 'Peter',
  'Mary', 'Linda', 'Susan', 'Karen', 'Lisa', 'Sarah', 'Nancy', 'Laura', 'Amy', 'Emma',
  'Anna', 'Grace', 'Rose', 'Jane', 'Emily', 'Nina', 'Sara', 'Mia', 'Lily', 'Eva',
];
const LAST_NAMES = [
  'Smith', 'Brown', 'Davis', 'Wilson', 'Taylor', 'Moore', 'Clark', 'Hall', 'White', 'Green',
  'Baker', 'King', 'Lee', 'Hill', 'Young', 'Allen', 'Scott', 'Adams', 'Nelson', 'Carter',
  'Turner', 'Walker', 'Parker', 'Collins', 'Morris', 'Reed', 'Cook', 'Bell', 'Ward', 'Gray',
];
const CITIES = ['Las Vegas', 'Reno', 'Henderson', 'Sparks', 'Carson City', 'Elko', 'Newark', 'Austin', 'Dallas'];
const STREET_NAMES = ['Main', 'Market', 'Broad', 'State', 'Center', 'Park', 'Oak', 'Maple', 'Lake', 'Hill'];
const LOGIN_DIGIT_LENGTHS = [1, 2, 3, 4, 5, 6, 7, 8];

export const pick = (items) => faker.helpers.arrayElement(items);
export const randDigits = (length) => Array.from({ length }, () => Math.floor(Math.random() * 10)).join('');
export const randomPhone = () => `${randDigits(3)}-${randDigits(3)}-${randDigits(4)}`;
export const randomZip = () => `${randomNumberWithDigitLength(5)}-${randDigits(4)}`;
export const randomStreet = () => `${randomNumberWithDigitLength(3)} ${pick(STREET_NAMES)} Street`;
export const randomUnit = () => `${pick(['Suite', 'Apt', 'Unit'])} ${randomNumberWithDigitLength(2)}`;
export const randomCity = () => pick(CITIES);
export const randomDob = () => `${String(Math.floor(Math.random() * 12) + 1).padStart(2, '0')}/${String(Math.floor(Math.random() * 28) + 1).padStart(2, '0')}/${Math.floor(Math.random() * 30) + 1970}`;

export function buildLoginName(product, digitLength = 1) {
  return `${product.loginPrefix}${randomNumberWithDigitLength(digitLength)}`;
}

export function buildUser(product) {
  const firstName = pick(FIRST_NAMES);
  const lastName = pick(LAST_NAMES);

  return {
    product: product.abbreviation,
    productName: product.productName,
    firstName,
    lastName,
    dob: randomDob(),
    ssn: randomSsn(),
    streetOne: randomStreet(),
    streetTwo: randomUnit(),
    city: randomCity(),
    zip: randomZip(),
    preferredCounty: 'NY',
    phone: randomPhone(),
    email: PRIMARY_EMAIL,
    altEmail: ALT_EMAIL,
    loginName: buildLoginName(product),
    password: DEFAULT_PASSWORD,
  };
}

export function refreshProfileData(product, user) {
  user.firstName = pick(FIRST_NAMES);
  user.lastName = pick(LAST_NAMES);
  user.dob = randomDob();
  user.ssn = randomSsn();
  user.streetOne = randomStreet();
  user.streetTwo = randomUnit();
  user.city = randomCity();
  user.zip = randomZip();
  user.phone = randomPhone();
  user.email = PRIMARY_EMAIL;
  user.altEmail = ALT_EMAIL;

  return user;
}

export function saveRegisteredUser(user) {
  const filePath = join(USER_DATA_DIR, `lastRegistered${user.product}User.json`);
  mkdirSync(dirname(filePath), { recursive: true });
  writeFileSync(filePath, `${JSON.stringify(user, null, 2)}\n`, 'utf-8');
  return filePath;
}

export async function waitForPageReady(page) {
  await page.waitForLoadState('domcontentloaded').catch(() => {});
  await page.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
  await waitForAspNetIdle(page);
}

export async function waitForAspNetIdle(page) {
  await page.evaluate(() => new Promise((resolve) => {
    const mgr = window.Sys?.WebForms?.PageRequestManager?.getInstance?.();
    if (!mgr || !mgr.get_isInAsyncPostBack()) {
      resolve();
      return;
    }

    const interval = setInterval(() => {
      if (!mgr.get_isInAsyncPostBack()) {
        clearInterval(interval);
        resolve();
      }
    }, 50);

    setTimeout(() => {
      clearInterval(interval);
      resolve();
    }, 15000);
  })).catch(() => {});

  await page.waitForTimeout(300);
}

export async function clickAndWait(page, locator) {
  const target = locator.first();
  await target.scrollIntoViewIfNeeded().catch(() => {});
  await target.click({ noWaitAfter: true });
  await waitForPageReady(page);
}

export async function firstVisibleText(page, text) {
  for (const locator of [
    page.getByText(text, { exact: true }),
    page.getByText(text, { exact: false }),
  ]) {
    const count = await locator.count().catch(() => 0);
    for (let index = 0; index < count; index += 1) {
      const candidate = locator.nth(index);
      if (await candidate.isVisible().catch(() => false)) {
        return candidate;
      }
    }
  }

  return page.getByText(text, { exact: false }).first();
}

export async function fillText(locator, value) {
  const target = locator.first();
  await expect(target).toBeVisible();
  await expect(target).toBeEnabled();
  await target.scrollIntoViewIfNeeded().catch(() => {});
  await target.fill(String(value));
}

export async function fillFirstText(page, names, value, { required = false } = {}) {
  for (const name of names) {
    const pattern = name instanceof RegExp ? name : new RegExp(escapeRegex(name), 'i');
    const candidates = [
      page.getByRole('textbox', { name: pattern }),
      page.getByLabel(pattern),
    ];

    for (const locator of candidates) {
      const count = await locator.count().catch(() => 0);
      for (let index = 0; index < count; index += 1) {
        const target = locator.nth(index);
        if (await target.isVisible().catch(() => false)) {
          await fillText(target, value);
          return true;
        }
      }
    }
  }

  if (required) {
    throw new Error(`Required text field was not available: ${names.join(', ')}`);
  }
  return false;
}

export async function fillRequiredText(page, names, value, options = {}) {
  if (await fillFirstText(page, names, value)) {
    return true;
  }

  const labelFragments = options.labelFragments || names.map((name) => (
    name instanceof RegExp ? name.source : String(name)
  ));

  if (await fillTextInputByLabelText(page, labelFragments, value, options)) {
    return true;
  }

  throw new Error(`Required text field was not available: ${labelFragments.join(', ')}`);
}

export async function clickOptionalOk(page, popup = null) {
  if (popup && !popup.isClosed()) {
    const ok = popup.getByRole('button', { name: /^OK$/i })
      .or(popup.getByRole('link', { name: /^OK$/i }))
      .first();

    if (await ok.isVisible({ timeout: 1500 }).catch(() => false)) {
      await ok.click({ noWaitAfter: true }).catch(() => {});
      await popup.close().catch(() => {});
      await waitForPageReady(page);
      return true;
    }
  }

  const ok = page.getByRole('button', { name: /^OK$/i })
    .or(page.getByRole('link', { name: /^OK$/i }))
    .first();

  if (await ok.isVisible({ timeout: 1000 }).catch(() => false)) {
    await clickAndWait(page, ok);
    return true;
  }

  return false;
}

export async function selectCounty(page, preferredValue = '', { required = false } = {}) {
  const county = page.getByLabel(/^County\s*\*?$/i)
    .or(page.getByRole('combobox', { name: /^County\s*\*?$/i }))
    .first();

  if (await county.count().catch(() => 0) && await county.isVisible().catch(() => false)) {
    if (preferredValue && await selectOptionIfPresent(county, preferredValue)) {
      await waitForPageReady(page);
      if (await hasSelectedValue(county)) {
        return true;
      }
    }

    await selectPreferredOrRandom(county);
    await waitForPageReady(page);
    if (await hasSelectedValue(county)) {
      return true;
    }
  }

  if (await selectDropdownByLabelText(page, ['County'], preferredValue)) {
    await waitForPageReady(page);
    return true;
  }

  if (required) {
    throw new Error('Required dropdown was not available or did not keep a value: County');
  }

  return false;
}

export async function fillDetoxCertificationFields(page, user, startupPopup = null) {
  await fillRequiredText(page, [/Last Name/i], user.lastName, { labelFragments: ['Last Name'] });
  await fillRequiredText(page, [/First Name/i], user.firstName, { labelFragments: ['First Name'] });
  await clickOptionalOk(page, startupPopup);
  await fillRequiredText(page, [/DOB/i, /Date of Birth/i], user.dob, { labelFragments: ['DOB', 'Date of Birth'] });
  await fillRequiredText(page, [/SSN/i], user.ssn, { labelFragments: ['SSN'] });
  await fillRequiredText(page, [/Street One/i, /Street 1/i, /Address Line 1/i], user.streetOne, { labelFragments: ['Street One', 'Street 1', 'Address Line 1'] });
  await fillFirstText(page, [/Street Two/i, /Street 2/i, /Address Line 2/i], user.streetTwo);
  await fillRequiredText(page, [/^City/i], user.city, { labelFragments: ['City'] });
  await fillRequiredText(page, [/^Zip/i, /Zip Code/i], user.zip, { labelFragments: ['Zip', 'Zip Code'] });
  await selectCounty(page, user.preferredCounty, { required: true });
  await fillRequiredText(page, [/^Phone(?! Ext)/i], user.phone, { labelFragments: ['Phone'], excludeFragments: ['Alt', 'Alternate', 'Ext'] });
  await fillRequiredText(page, [/Primary\s*E.?mail/i, /^Email\b/i], user.email, {
    labelFragments: ['Primary E-mail', 'Primary Email', 'Email'],
    excludeFragments: ['Alt', 'Alternate'],
  });
  await fillFirstText(page, [/Alt Email/i, /Alternate Email/i], user.altEmail);
  await ensureDetoxRequiredFields(page, user);
}

export async function fillAccountFields(page, user) {
  await fillFirstText(page, [/Login Name/i], user.loginName, { required: true });
  await fillFirstText(page, [/^Password/i], user.password, { required: true });
  await fillFirstText(page, [/Re-type Password/i, /Confirm Password/i], user.password, { required: true });
}

export async function submitRegistration(page) {
  const register = page.getByRole('link', { name: /^Register$/i })
    .or(page.getByRole('button', { name: /^Register$/i }))
    .first();

  await clickAndWait(page, register);
}

export async function getVisibleValidationText(page) {
  const validationText = await page
    .locator('li, .validation-summary-errors, .field-validation-error, [id*="ValidationSummary"], [id*="valSummary"], [id*="RequiredFieldValidator"], [id*="RegularExpressionValidator"]')
    .evaluateAll((elements) => elements.map((element) => element.textContent ?? '').join('\n'))
    .catch(() => '');

  return validationText
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => /required|invalid|does not match|already|unique|taken|must select|please enter/i.test(line))
    .filter((line) => !/Fields marked|Password is case sensitive/i.test(line))
    .join(' ');
}

export async function isDuplicateLoginVisible(page) {
  const bodyText = await page.locator('body').innerText().catch(() => '');
  return /login name.*(already|exists|unique|taken)|already.*login name/i.test(bodyText);
}

export async function getDuplicateProfileText(page) {
  const bodyText = await page.locator('body').innerText().catch(() => '');
  const bodyHtml = await page.locator('body').evaluate((element) => element.innerHTML).catch(() => '');
  const combined = `${bodyText}\n${bodyHtml}`;

  return /profile with this data already exists|another profile cannot be created|data already exists/i.test(combined)
    ? 'Profile with this data already exists.'
    : '';
}

export async function isRegistrationFormOpen(page) {
  const register = page.getByRole('link', { name: /^Register$/i })
    .or(page.getByRole('button', { name: /^Register$/i }))
    .first();
  const loginName = page.getByRole('textbox', { name: /Login Name/i }).first();

  return await register.isVisible().catch(() => false)
    && await loginName.isVisible().catch(() => false);
}

export function nextLoginNameForAttempt(product, previousLoginName, attemptIndex) {
  const digitLength = LOGIN_DIGIT_LENGTHS[Math.min(Math.max(0, attemptIndex - 1), LOGIN_DIGIT_LENGTHS.length - 1)];
  let nextLoginName;

  do {
    nextLoginName = buildLoginName(product, digitLength);
  } while (nextLoginName === previousLoginName);

  return nextLoginName;
}

async function selectOptionIfPresent(locator, value) {
  const hasValue = await locator.evaluate((select, optionValue) => (
    Array.from(select.options || []).some((option) => option.value === optionValue && !option.disabled)
  ), value).catch(() => false);

  if (!hasValue) {
    return false;
  }

  await locator.selectOption(value);
  return true;
}

async function hasSelectedValue(locator) {
  const value = await locator.inputValue({ timeout: 1000 }).catch(() => '');
  return Boolean(String(value || '').trim());
}

async function fillTextInputByLabelText(page, labelFragments, value, { excludeFragments = [] } = {}) {
  return page.evaluate(({ labelFragments: rawLabelFragments, excludeFragments: rawExcludeFragments, value: nextValue }) => {
    const labelFragments = rawLabelFragments.map(normalize).filter(Boolean);
    const excludeFragments = rawExcludeFragments.map(normalize).filter(Boolean);
    const controls = Array.from(document.querySelectorAll('input:not([type="hidden"]):not([type="button"]):not([type="submit"]), textarea'))
      .filter((control) => !control.disabled && isVisible(control));

    for (const control of controls) {
      const text = controlTexts(control).map(normalize).join(' ');
      if (!labelFragments.some((fragment) => text.includes(fragment))) {
        continue;
      }

      if (excludeFragments.some((fragment) => text.includes(fragment))) {
        continue;
      }

      control.scrollIntoView({ block: 'center', inline: 'nearest' });
      control.focus();
      control.value = nextValue;
      control.dispatchEvent(new Event('input', { bubbles: true }));
      control.dispatchEvent(new Event('change', { bubbles: true }));
      control.blur();
      return true;
    }

    return false;

    function isVisible(element) {
      const style = window.getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return style.visibility !== 'hidden' && style.display !== 'none' && rect.width > 0 && rect.height > 0;
    }

    function normalize(text) {
      return String(text || '')
        .replace(/\u00a0/g, ' ')
        .replace(/\*/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .toLowerCase();
    }

    function controlTexts(control) {
      const labels = Array.from(document.querySelectorAll('label'))
        .filter((label) => label.htmlFor && label.htmlFor === control.id)
        .map((label) => label.textContent);
      const cell = control.closest('td, th');
      const row = control.closest('tr');
      const previousCell = cell?.previousElementSibling?.textContent;

      return [
        control.getAttribute('aria-label'),
        control.getAttribute('title'),
        control.getAttribute('placeholder'),
        control.name,
        control.id,
        control.closest('label')?.textContent,
        previousCell,
        row?.textContent,
        ...labels,
      ].filter(Boolean);
    }
  }, { labelFragments, excludeFragments, value });
}

async function selectDropdownByLabelText(page, labelFragments, preferredValue = '') {
  return page.evaluate(({ labelFragments: rawLabelFragments, preferredValue: requestedValue }) => {
    const labelFragments = rawLabelFragments.map(normalize).filter(Boolean);
    const selects = Array.from(document.querySelectorAll('select'))
      .filter((select) => !select.disabled && isVisible(select));

    for (const select of selects) {
      const text = controlTexts(select).map(normalize).join(' ');
      if (!labelFragments.some((fragment) => text.includes(fragment))) {
        continue;
      }

      const options = Array.from(select.options || [])
        .filter((option) => !option.disabled && option.value && !/^--|choose|select/i.test(String(option.textContent || '').trim()));
      const option = options.find((candidate) => candidate.value === requestedValue) || options[0];

      if (!option) {
        continue;
      }

      select.scrollIntoView({ block: 'center', inline: 'nearest' });
      select.value = option.value;
      option.selected = true;
      select.dispatchEvent(new Event('input', { bubbles: true }));
      select.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }

    return false;

    function isVisible(element) {
      const style = window.getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      return style.visibility !== 'hidden' && style.display !== 'none' && rect.width > 0 && rect.height > 0;
    }

    function normalize(text) {
      return String(text || '')
        .replace(/\u00a0/g, ' ')
        .replace(/\*/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .toLowerCase();
    }

    function controlTexts(control) {
      const labels = Array.from(document.querySelectorAll('label'))
        .filter((label) => label.htmlFor && label.htmlFor === control.id)
        .map((label) => label.textContent);
      const cell = control.closest('td, th');
      const row = control.closest('tr');
      const previousCell = cell?.previousElementSibling?.textContent;

      return [
        control.getAttribute('aria-label'),
        control.getAttribute('title'),
        control.name,
        control.id,
        previousCell,
        row?.textContent,
        ...labels,
      ].filter(Boolean);
    }
  }, { labelFragments, preferredValue });
}

async function ensureDetoxRequiredFields(page, user) {
  await fillRequiredText(page, [/DOB/i, /Date of Birth/i], user.dob, { labelFragments: ['DOB', 'Date of Birth'] });
  await selectCounty(page, user.preferredCounty, { required: true });
  await fillRequiredText(page, [/Primary\s*E.?mail/i, /^Email\b/i], user.email, {
    labelFragments: ['Primary E-mail', 'Primary Email', 'Email'],
    excludeFragments: ['Alt', 'Alternate'],
  });
}

async function selectPreferredOrRandom(locator) {
  const options = await locator.evaluate((select) => Array.from(select.options)
    .filter((option) => !option.disabled && option.value && !/^--|choose|select/i.test(option.textContent.trim()))
    .map((option) => option.value));

  if (!options.length) {
    return false;
  }

  await locator.selectOption(pick(options));
  return true;
}

function randomNumberWithDigitLength(length) {
  if (length <= 1) {
    return String(Math.floor(Math.random() * 9) + 1);
  }

  const min = 10 ** (length - 1);
  const max = (10 ** length) - 1;
  return String(Math.floor(Math.random() * (max - min + 1)) + min);
}

function randomSsn() {
  const area = Math.floor(Math.random() * (665 - 200 + 1)) + 200;
  const group = String(Math.floor(Math.random() * 99) + 1).padStart(2, '0');
  const serial = String(Math.floor(Math.random() * 9999) + 1).padStart(4, '0');
  return `${area}-${group}-${serial}`;
}

function escapeRegex(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
