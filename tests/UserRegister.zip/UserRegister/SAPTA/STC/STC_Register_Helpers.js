import { mkdirSync, writeFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { expect } from '@playwright/test';
import { faker } from '@faker-js/faker';

const currentFile = fileURLToPath(import.meta.url);
const testsRoot = dirname(dirname(currentFile));

export const LOGIN_URL = 'http://172.16.3.2/ALiSNVSAPTA2TESTING11.4.38.04/LoginBHCEN.aspx';
export const DEFAULT_PASSWORD = 'Password@1';
export const PRIMARY_EMAIL = 'mohdatif.jamal@ops1.advancedgrc.com';
export const ALT_EMAIL = 'mohdatif.jamal@ops1.advancedgrc.com';
export const USER_DATA_DIR = join(testsRoot, 'testData');

export const PRODUCT = {
  abbreviation: 'STC',
  productName: 'State Treatment Certification',
  sectionText: 'Behavioral Health Certifications for Excellence in Nevada',
  registrationLinkId: 'm_LoginControl_LinkButton9',
  loginPrefix: 'STC_',
  entityPrefix: 'STC',
};

const FIRST_NAMES = [
  'John', 'Mike', 'David', 'James', 'Robert', 'Chris', 'Mark', 'Paul', 'Steve', 'Kevin',
  'Brian', 'Adam', 'Eric', 'Ryan', 'Jason', 'Tom', 'Ben', 'Sam', 'Alex', 'Peter',
  'Mary', 'Linda', 'Susan', 'Karen', 'Lisa', 'Sarah', 'Nancy', 'Laura', 'Amy', 'Emma',
  'Anna', 'Grace', 'Rose', 'Jane', 'Emily', 'Nina', 'Sara', 'Mia', 'Lily', 'Eva',
];
const LAST_NAMES = [
  'Smith', 'Brown', 'Davis', 'Wilson', 'Taylor', 'Moore', 'Clark', 'Hall', 'White', 'Green',
  'Baker', 'King', 'Lee', 'Hill', 'Young', 'Allen', 'Scott', 'Adams', 'Nelson', 'Carter',
  'Turner', 'Walker', 'Parker', 'Collins', 'Morris', 'Reed', 'Cook', 'Bell', 'Ward', 'Gray',
];
const CITIES = ['Las Vegas', 'Reno', 'Henderson', 'Sparks', 'Carson City', 'Elko', 'Newark', 'Austin', 'Dallas'];
const STREET_NAMES = ['Main', 'Market', 'Broad', 'State', 'Center', 'Park', 'Oak', 'Maple', 'Lake', 'Hill'];
const LOGIN_DIGIT_LENGTHS = [1, 2, 3, 4, 5, 6, 7, 8];

export const pick = (items) => faker.helpers.arrayElement(items);
export const randDigits = (length) => Array.from({ length }, () => Math.floor(Math.random() * 10)).join('');
export const randomPhone = () => `${randDigits(3)}-${randDigits(3)}-${randDigits(4)}`;
export const randomZip = () => `${randomNumberWithDigitLength(5)}-${randDigits(4)}`;
export const randomStreet = () => `${randomNumberWithDigitLength(3)} ${pick(STREET_NAMES)} Street`;
export const randomUnit = () => `${pick(['Suite', 'Apt', 'Unit'])} ${randomNumberWithDigitLength(2)}`;
export const randomCity = () => pick(CITIES);

export function currentDateParts() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, '0');
  const hours24 = now.getHours();
  const hours12 = hours24 % 12 || 12;
  const ampm = hours24 >= 12 ? 'PM' : 'AM';

  return {
    dateForName: `${pad(now.getDate())}-${pad(now.getMonth() + 1)}-${now.getFullYear()}`,
    timeForName: `${pad(hours12)}:${pad(now.getMinutes())}:${pad(now.getSeconds())} ${ampm}`,
  };
}

export function buildEntityName(prefix) {
  const { dateForName, timeForName } = currentDateParts();
  return `${prefix}_${dateForName}_${timeForName}`;
}

export function buildLoginName(product, digitLength = 1) {
  return `${product.loginPrefix}${randomNumberWithDigitLength(digitLength)}`;
}

export function buildUser(product) {
  const firstName = pick(FIRST_NAMES);
  const lastName = pick(LAST_NAMES);

  return {
    product: product.abbreviation,
    productName: product.productName,
    firstName,
    lastName,
    providerName: buildEntityName(product.entityPrefix),
    nvBusinessId: `NV${randomNumberWithDigitLength(11)}`,
    streetOne: randomStreet(),
    streetTwo: randomUnit(),
    city: randomCity(),
    zip: randomZip(),
    phone: randomPhone(),
    email: PRIMARY_EMAIL,
    altEmail: ALT_EMAIL,
    loginName: buildLoginName(product),
    password: DEFAULT_PASSWORD,
  };
}

export function refreshProfileData(product, user) {
  user.firstName = pick(FIRST_NAMES);
  user.lastName = pick(LAST_NAMES);
  user.providerName = buildEntityName(product.entityPrefix);
  user.nvBusinessId = `NV${randomNumberWithDigitLength(11)}`;
  user.streetOne = randomStreet();
  user.streetTwo = randomUnit();
  user.city = randomCity();
  user.zip = randomZip();
  user.phone = randomPhone();
  user.email = PRIMARY_EMAIL;
  user.altEmail = ALT_EMAIL;

  return user;
}

export function saveRegisteredUser(user) {
  const filePath = join(USER_DATA_DIR, `lastRegistered${user.product}User.json`);
  mkdirSync(dirname(filePath), { recursive: true });
  writeFileSync(filePath, `${JSON.stringify(user, null, 2)}\n`, 'utf-8');
  return filePath;
}

export async function waitForPageReady(page) {
  await page.waitForLoadState('domcontentloaded').catch(() => {});
  await page.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
  await waitForAspNetIdle(page);
}

export async function waitForAspNetIdle(page) {
  await page.evaluate(() => new Promise((resolve) => {
    const mgr = window.Sys?.WebForms?.PageRequestManager?.getInstance?.();
    if (!mgr || !mgr.get_isInAsyncPostBack()) {
      resolve();
      return;
    }

    const interval = setInterval(() => {
      if (!mgr.get_isInAsyncPostBack()) {
        clearInterval(interval);
        resolve();
      }
    }, 50);

    setTimeout(() => {
      clearInterval(interval);
      resolve();
    }, 15000);
  })).catch(() => {});

  await page.waitForTimeout(300);
}

export async function clickAndWait(page, locator) {
  const target = locator.first();
  await target.scrollIntoViewIfNeeded().catch(() => {});
  await target.click({ noWaitAfter: true });
  await waitForPageReady(page);
}

export async function firstVisibleText(page, text) {
  for (const locator of [
    page.getByText(text, { exact: true }),
    page.getByText(text, { exact: false }),
  ]) {
    const count = await locator.count().catch(() => 0);
    for (let index = 0; index < count; index++) {
      const candidate = locator.nth(index);
      if (await candidate.isVisible().catch(() => false)) return candidate;
    }
  }

  return page.getByText(text, { exact: false }).first();
}

export async function fillText(locator, value) {
  const target = locator.first();
  await expect(target).toBeVisible();
  await expect(target).toBeEnabled();
  await target.scrollIntoViewIfNeeded().catch(() => {});
  await target.fill(String(value));
  await verifyFilledValue(target, value);
}

export async function fillFirstText(page, names, value, { required = false } = {}) {
  for (const name of names) {
    const pattern = name instanceof RegExp ? name : new RegExp(escapeRegex(name), 'i');
    const candidates = [
      page.getByRole('textbox', { name: pattern }),
      page.getByLabel(pattern),
    ];

    for (const locator of candidates) {
      const count = await locator.count().catch(() => 0);
      for (let index = 0; index < count; index++) {
        const target = locator.nth(index);
        if (await target.isVisible().catch(() => false)) {
          await fillText(target, value);
          return true;
        }
      }
    }
  }

  if (required) throw new Error(`Required text field was not available: ${names.join(', ')}`);
  return false;
}

export async function fillTextboxInRow(page, rowName, textboxName, value, { required = false } = {}) {
  const rowPattern = rowName instanceof RegExp ? rowName : new RegExp(escapeRegex(rowName), 'i');
  const textboxPattern = textboxName instanceof RegExp ? textboxName : new RegExp(escapeRegex(textboxName), 'i');
  const rows = page.getByRole('row', { name: rowPattern });
  const rowCount = await rows.count().catch(() => 0);

  for (let index = 0; index < rowCount; index += 1) {
    const row = rows.nth(index);
    if (!(await row.isVisible().catch(() => false))) continue;

    const textbox = row.getByRole('textbox', { name: textboxPattern });
    const target = await firstVisibleLocator(textbox);
    if (target) {
      await fillText(target, value);
      return true;
    }
  }

  if (required) throw new Error(`Required row text field was not available: ${rowPattern} / ${textboxPattern}`);
  return false;
}

export async function selectRandomCounty(page, { required = false } = {}) {
  if (await selectByTableLabel(page, /^County\b/i)) return true;

  const county = await firstVisibleLocator(page.getByRole('row', { name: /County/i }).getByRole('combobox', { name: /County/i }))
    ?? await firstVisibleLocator(page.getByLabel(/^County\s*\*?$/i))
    ?? await firstVisibleLocator(page.getByRole('combobox', { name: /^County\s*\*?$/i }));

  if (!county) {
    if (required) throw new Error('Required County dropdown was not available.');
    return false;
  }

  for (let attempt = 1; attempt <= 5; attempt += 1) {
    await selectPreferredOrRandom(county);
    await waitForPageReady(page);

    if (await hasSelectedNonPlaceholderOption(county)) {
      return true;
    }
  }

  if (required) throw new Error('Required County dropdown did not keep a selected value.');
  return false;
}

export async function fillProviderRegistrationFields(page, user) {
  await fillFirstText(page, [/Provider Name/i], user.providerName, { required: true });
  await fillFirstText(page, [/NV Business ID/i], user.nvBusinessId, { required: true });
  await fillFirstText(page, [/Street One/i, /Street 1/i, /Address Line 1/i], user.streetOne, { required: true });
  await fillFirstText(page, [/Street Two/i, /Street 2/i, /Address Line 2/i], user.streetTwo);
  await fillFirstText(page, [/^City/i], user.city, { required: true });
  await fillFirstText(page, [/^Zip/i, /Zip Code/i], user.zip, { required: true });
  await page.keyboard.press('Tab').catch(() => {});
  await waitForPageReady(page);
  await selectRandomCounty(page, { required: true });
  await fillFirstText(page, [/^Phone(?! Ext)/i], user.phone, { required: true });
  await fillPrimaryEmail(page, user.email);
  await fillAlternateEmail(page, user.altEmail);
}

export async function fillAccountFields(page, user) {
  await fillFirstText(page, [/Login Name/i], user.loginName, { required: true });
  await fillFirstText(page, [/^Password/i], user.password, { required: true });
  await fillFirstText(page, [/Re-type Password/i, /Confirm Password/i], user.password, { required: true });
}

export async function submitRegistration(page) {
  const register = page.getByRole('link', { name: /^Register$/i })
    .or(page.getByRole('button', { name: /^Register$/i }))
    .first();

  await clickAndWait(page, register);
}

export async function getVisibleValidationText(page) {
  const validationText = await page
    .locator('li, .validation-summary-errors, .field-validation-error, [id*="ValidationSummary"], [id*="valSummary"], [id*="RequiredFieldValidator"], [id*="RegularExpressionValidator"]')
    .evaluateAll((elements) => elements.map((element) => element.textContent ?? '').join('\n'))
    .catch(() => '');

  return validationText
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => /required|invalid|does not match|already|unique|taken|must select|please enter/i.test(line))
    .filter((line) => !/Fields marked|Password is case sensitive/i.test(line))
    .join(' ');
}

export async function isDuplicateLoginVisible(page) {
  const bodyText = await page.locator('body').innerText().catch(() => '');
  return /login name.*(already|exists|unique|taken)|already.*login name/i.test(bodyText);
}

export async function getDuplicateProfileText(page) {
  const bodyText = await page.locator('body').innerText().catch(() => '');
  const bodyHtml = await page.locator('body').evaluate((element) => element.innerHTML).catch(() => '');
  const combined = `${bodyText}\n${bodyHtml}`;

  return /profile with this data already exists|another profile cannot be created|data already exists/i.test(combined)
    ? 'Profile with this data already exists.'
    : '';
}

export async function isRegistrationFormOpen(page) {
  const register = page.getByRole('link', { name: /^Register$/i })
    .or(page.getByRole('button', { name: /^Register$/i }))
    .first();
  const loginName = page.getByRole('textbox', { name: /Login Name/i }).first();

  return await register.isVisible().catch(() => false)
    && await loginName.isVisible().catch(() => false);
}

export function nextLoginNameForAttempt(product, previousLoginName, attemptIndex) {
  const digitLength = LOGIN_DIGIT_LENGTHS[Math.min(Math.max(0, attemptIndex - 1), LOGIN_DIGIT_LENGTHS.length - 1)];
  let nextLoginName;

  do {
    nextLoginName = buildLoginName(product, digitLength);
  } while (nextLoginName === previousLoginName);

  return nextLoginName;
}

async function selectPreferredOrRandom(locator) {
  const options = await locator.evaluate((select) => Array.from(select.options)
    .map((option, index) => ({
      index,
      value: option.value,
      label: option.textContent?.trim() ?? '',
      disabled: option.disabled,
    }))
  ).then((selectOptions) => selectOptions
    .filter((option) => !option.disabled && !isPlaceholderOption(option.value, option.label)));

  if (!options.length) return false;

  const selectedOption = pick(options);
  if (selectedOption.value) {
    await locator.selectOption(selectedOption.value);
  } else {
    await locator.selectOption({ index: selectedOption.index });
  }

  await locator.evaluate((select) => {
    select.dispatchEvent(new Event('input', { bubbles: true }));
    select.dispatchEvent(new Event('change', { bubbles: true }));
    select.blur();
  }).catch(() => {});

  return true;
}

async function fillPrimaryEmail(page, email) {
  const filled = await fillByTableLabel(page, /Primary\s+E-?mail/i, email)
    || await fillTextboxInRow(page, /Primary\s+E-?mail/i, /^Email$/i, email)
    || await fillFirstText(page, [/Primary\s+E-?mail/i, /^Email\b/i], email);

  if (!filled) throw new Error('Required Primary E-mail field was not available.');
}

async function fillAlternateEmail(page, email) {
  await fillByTableLabel(page, /Alternate\s+E-?mail/i, email)
    || await fillTextboxInRow(page, /Alternate\s+E-?mail|Alt\s+Email/i, /Alt\s+Email|Alternate/i, email)
    || await fillFirstText(page, [/Alt\s+Email/i, /Alternate\s+E-?mail/i, /Alternate\s+Email/i], email);
}

async function fillByTableLabel(page, labelPattern, value) {
  const target = await inputAfterTableLabel(page, labelPattern, 'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]), textarea');
  if (!target) return false;

  await fillText(target, value);
  return true;
}

async function selectByTableLabel(page, labelPattern, { required = false } = {}) {
  const target = await inputAfterTableLabel(page, labelPattern, 'select');
  if (!target) {
    if (required) throw new Error(`Required select field was not available for label: ${labelPattern}`);
    return false;
  }

  for (let attempt = 1; attempt <= 5; attempt += 1) {
    await selectPreferredOrRandom(target);
    await waitForPageReady(page);

    if (await hasSelectedNonPlaceholderOption(target)) return true;
  }

  if (required) throw new Error(`Required select field did not keep a value for label: ${labelPattern}`);
  return false;
}

async function inputAfterTableLabel(page, labelPattern, inputSelector) {
  const matches = await page.locator('td, th, label, span').evaluateAll((elements, patternText) => {
    const pattern = new RegExp(patternText, 'i');
    return elements
      .map((element, index) => ({ element, index }))
      .map(({ element, index }) => ({
        index,
        text: element.textContent?.replace(/\s+/g, ' ').trim() ?? '',
      }))
      .filter(({ text }) => text.length > 0 && text.length <= 80 && pattern.test(text))
      .sort((left, right) => left.text.length - right.text.length)
      .map(({ index }) => index);
  }, labelPattern.source).catch(() => []);

  const labels = page.locator('td, th, label, span');
  for (const index of matches) {
    const label = labels.nth(index);
    const directTarget = label.locator(`xpath=following::*[self::input or self::select or self::textarea][not(@type="hidden")][1]`).first();
    const matchesSelector = await directTarget.evaluate((element, selector) => element.matches(selector), inputSelector).catch(() => false);
    if (matchesSelector && await directTarget.isVisible().catch(() => false)) return directTarget;
  }

  return null;
}

async function firstVisibleLocator(locator) {
  const count = await locator.count().catch(() => 0);
  for (let index = 0; index < count; index += 1) {
    const candidate = locator.nth(index);
    if (await candidate.isVisible().catch(() => false)) return candidate;
  }

  return null;
}

async function hasSelectedNonPlaceholderOption(locator) {
  return locator.evaluate((select) => {
    const option = select.options[select.selectedIndex];
    if (!option) return false;

    const value = option.value ?? '';
    const label = option.textContent?.trim() ?? '';
    return Boolean(!option.disabled && !/^--|choose|select|mandatory$/i.test(label) && value !== '' && value !== '-1' && value !== '0');
  }).catch(() => false);
}

async function verifyFilledValue(locator, value) {
  const expectedValue = String(value);
  const actualValue = await locator.inputValue({ timeout: 1000 }).catch(() => expectedValue);

  if (actualValue === expectedValue) return;

  await locator.evaluate((element, nextValue) => {
    element.value = nextValue;
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.blur();
  }, expectedValue).catch(() => {});

  await expect(locator).toHaveValue(expectedValue, { timeout: 3000 });
}

function isPlaceholderOption(value, label) {
  return !value || value === '-1' || value === '0' || /^--|choose|select|mandatory$/i.test(label);
}

function randomNumberWithDigitLength(length) {
  if (length <= 1) return String(Math.floor(Math.random() * 9) + 1);

  const min = 10 ** (length - 1);
  const max = (10 ** length) - 1;
  return String(Math.floor(Math.random() * (max - min + 1)) + min);
}

function escapeRegex(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
