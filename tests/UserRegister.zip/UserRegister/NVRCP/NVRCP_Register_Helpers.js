import { mkdirSync, writeFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { faker } from '@faker-js/faker';

const currentFile = fileURLToPath(import.meta.url);
const testsRoot = dirname(dirname(currentFile));

export const LOGIN_URL = 'http://172.16.3.2/ALiSNVRCP2TESTING11.4.37.03/LoginRadiation.aspx';
export const DEFAULT_PASSWORD = 'Password@1';
export const PRIMARY_EMAIL = 'mohdatif.jamal@ops1.advancedgrc.com';
export const ALT_EMAIL = 'mohdatif.jamal@ops1.advancedgrc.com';
export const USER_DATA_DIR = join(testsRoot, 'testData');

export const PRODUCT_CONFIGS = [
  {
    abbreviation: 'RPM',
    productName: 'Radiation Producing Machine',
    sectionText: 'Radiation Producing Machines',
    registrationLinkId: 'm_LoginControl_LinkButton5',
    loginPrefix: 'RPM_',
    formType: 'facility',
    entityPrefix: 'RPM',
  },
  {
    abbreviation: 'RPM_INS',
    productName: 'Radiation Producing Machine Installer',
    sectionText: 'Radiation Producing Machines',
    registrationLinkId: 'm_LoginControl_LinkButton9',
    loginPrefix: 'RPM_Ins_',
    formType: 'facility',
    entityPrefix: 'RPM_Ins',
  },
  {
    abbreviation: 'RM',
    productName: 'Radioactive Materials',
    sectionText: 'Radioactive Materials',
    registrationLinkName: 'Click Here',
    loginPrefix: 'RM_',
    formType: 'facility',
    entityPrefix: 'RM',
  },
  {
    abbreviation: 'MAMMO',
    productName: 'Mammographer',
    sectionText: 'Mammographers and MQSA',
    registrationLinkId: 'm_LoginControl_LinkButton17',
    loginPrefix: 'Mammo_',
    formType: 'person',
    entityPrefix: 'Mammo',
  },
  {
    abbreviation: 'MQSA',
    productName: 'MQSA Machine',
    sectionText: 'Mammographers and MQSA',
    registrationLinkId: 'm_LoginControl_LinkButton18',
    loginPrefix: 'MQSA_',
    formType: 'facility',
    entityPrefix: 'MQSA',
  },
  {
    abbreviation: 'PLR',
    productName: 'Professional Licensing and registrations FULL License/Credentials',
    sectionText: 'Professional Licensing and',
    registrationLinkId: 'm_LoginControl_LinkButton13',
    loginPrefix: 'PLR_',
    formType: 'person',
    entityPrefix: 'PLR',
  },
  {
    abbreviation: 'RTRI',
    productName: 'Radiation Therapy and Radiologic Imaging',
    sectionText: 'Professional Licensing and',
    registrationLinkId: 'm_LoginControl_LinkButton10',
    loginPrefix: 'RTRI_',
    formType: 'person',
    entityPrefix: 'RTRI',
  },
  {
    abbreviation: 'CTF',
    productName: 'CT or Fluoroscopy',
    sectionText: 'Professional Licensing and',
    registrationLinkId: 'm_LoginControl_LinkButton4',
    loginPrefix: 'CTF_',
    formType: 'person',
    entityPrefix: 'CTF',
  },
  {
    abbreviation: 'RURAL',
    productName: 'Rural Authorization',
    sectionText: 'Professional Licensing and',
    registrationLinkId: 'm_LoginControl_LinkButton15',
    loginPrefix: 'Rural_',
    formType: 'person',
    entityPrefix: 'Rural',
  },
  {
    abbreviation: 'CTOMO',
    productName: 'Computed Tomography',
    sectionText: 'Professional Licensing and',
    registrationLinkId: 'm_LoginControl_LinkButton6',
    loginPrefix: 'CTomo_',
    formType: 'person',
    entityPrefix: 'CTomo',
  },
  {
    abbreviation: 'OUTSIDE',
    productName: 'License to practice outside scope of practice',
    sectionText: 'Professional Licensing and',
    registrationLinkId: 'm_LoginControl_LinkButton8',
    loginPrefix: 'Outside_',
    formType: 'person',
    entityPrefix: 'Outside',
  },
];

const FIRST_NAMES = [
  'John', 'Mike', 'David', 'James', 'Robert',
  'Chris', 'Mark', 'Paul', 'Steve', 'Kevin',
  'Brian', 'Adam', 'Eric', 'Ryan', 'Jason',
  'Mary', 'Linda', 'Susan', 'Karen', 'Lisa',
  'Sarah', 'Nancy', 'Laura', 'Amy', 'Emma',
];
const LAST_NAMES = [
  'Smith', 'Brown', 'Davis', 'Wilson', 'Taylor',
  'Moore', 'Clark', 'Hall', 'White', 'Green',
  'Baker', 'King', 'Lee', 'Hill', 'Young',
];
const CITIES = ['Las Vegas', 'Reno', 'Henderson', 'Sparks', 'Carson City', 'Elko'];
const STREET_NAMES = ['Main', 'Market', 'Broad', 'State', 'Center', 'Park'];
const LOGIN_DIGIT_LENGTHS = [1, 2, 3, 5, 6, 7, 8];

export const pick = (items) => faker.helpers.arrayElement(items);
export const randDigits = (length) => Array.from({ length }, () => Math.floor(Math.random() * 10)).join('');
export const randomPhone = () => `${randDigits(3)}-${randDigits(3)}-${randDigits(4)}`;
export const randomZip = () => `${randomNumberWithDigitLength(5)}-${randDigits(4)}`;
export const randomStreet = () => `${randomNumberWithDigitLength(3)} ${pick(STREET_NAMES)} Street`;
export const randomUnit = () => `${pick(['Suite', 'Apt', 'Unit'])} ${randomNumberWithDigitLength(2)}`;
export const randomCity = () => pick(CITIES);

export function timestampParts() {
  const now = new Date();
  const pad = (value) => String(value).padStart(2, '0');
  const hours24 = now.getHours();
  const hours12 = hours24 % 12 || 12;
  const ampm = hours24 >= 12 ? 'PM' : 'AM';

  return {
    date: `${pad(now.getDate())}-${pad(now.getMonth() + 1)}-${now.getFullYear()}`,
    time: `${pad(hours12)}:${pad(now.getMinutes())}:${pad(now.getSeconds())} ${ampm}`,
  };
}

export function buildEntityName(prefix) {
  const { date, time } = timestampParts();
  return `${prefix}_${date}_${time}`;
}

export function buildLoginName(product, digitLength = 1) {
  return `${product.loginPrefix}${randomNumberWithDigitLength(digitLength)}`;
}

export function buildUser(product) {
  const user = {
    product: product.abbreviation,
    productName: product.productName,
    formType: product.formType,
    firstName: pick(FIRST_NAMES),
    lastName: pick(LAST_NAMES),
    facilityName: buildEntityName(product.entityPrefix),
    nvBusinessId: `NV${randomNumberWithDigitLength(7)}`,
    localLicense: randomNumberWithDigitLength(4),
    facilityType: '02',
    ssn: randomSsn(),
    apiNumber: `API${randomNumberWithDigitLength(4)}`,
    arrtNumber: randomNumberWithDigitLength(9),
    streetOne: randomStreet(),
    streetTwo: randomUnit(),
    city: randomCity(),
    zip: randomZip(),
    phone: randomPhone(),
    email: PRIMARY_EMAIL,
    altEmail: ALT_EMAIL,
    loginName: buildLoginName(product),
    password: DEFAULT_PASSWORD,
  };

  return user;
}

export function refreshProfileData(product, user) {
  user.firstName = pick(FIRST_NAMES);
  user.lastName = pick(LAST_NAMES);
  user.facilityName = buildEntityName(product.entityPrefix);
  user.nvBusinessId = `NV${randomNumberWithDigitLength(7)}`;
  user.localLicense = randomNumberWithDigitLength(4);
  user.ssn = randomSsn();
  user.apiNumber = `API${randomNumberWithDigitLength(4)}`;
  user.arrtNumber = randomNumberWithDigitLength(9);
  user.streetOne = randomStreet();
  user.streetTwo = randomUnit();
  user.city = randomCity();
  user.zip = randomZip();
  user.phone = randomPhone();
  user.email = PRIMARY_EMAIL;
  user.altEmail = ALT_EMAIL;

  return user;
}

export function saveRegisteredUser(user) {
  const filePath = join(USER_DATA_DIR, `lastRegisteredNVRCP${user.product}User.json`);
  mkdirSync(dirname(filePath), { recursive: true });
  writeFileSync(filePath, `${JSON.stringify(user, null, 2)}\n`, 'utf-8');
  return filePath;
}

export async function waitForPageReady(page) {
  await page.waitForLoadState('domcontentloaded').catch(() => {});
  await page.waitForLoadState('networkidle', { timeout: 8000 }).catch(() => {});
  await waitForAspNetIdle(page);
}

export async function waitForAspNetIdle(page) {
  await page.evaluate(() => new Promise((resolve) => {
    const mgr = window.Sys?.WebForms?.PageRequestManager?.getInstance?.();
    if (!mgr || !mgr.get_isInAsyncPostBack()) {
      resolve();
      return;
    }

    const interval = setInterval(() => {
      if (!mgr.get_isInAsyncPostBack()) {
        clearInterval(interval);
        resolve();
      }
    }, 50);

    setTimeout(() => {
      clearInterval(interval);
      resolve();
    }, 15000);
  })).catch(() => {});

  await page.waitForTimeout(300);
}

export async function clickAndWait(page, locator) {
  await locator.scrollIntoViewIfNeeded().catch(() => {});
  await locator.click({ noWaitAfter: true });
  await waitForPageReady(page);
}

export async function fillText(locator, value) {
  const { expect } = await import('@playwright/test');
  const target = locator.first();
  await expect(target).toBeVisible();
  await expect(target).toBeEnabled();
  await target.scrollIntoViewIfNeeded().catch(() => {});
  await target.fill(String(value));
}

export async function fillFirstText(page, names, value) {
  for (const name of names) {
    const pattern = name instanceof RegExp ? name : new RegExp(`^${escapeRegex(name)}\\s*\\*?$`, 'i');
    const candidates = [
      page.getByRole('textbox', { name: pattern }),
      page.getByLabel(pattern),
    ];

    for (const locator of candidates) {
      if (await locator.count().catch(() => 0)) {
        const target = locator.first();
        if (await target.isVisible().catch(() => false)) {
          await fillText(target, value);
          return true;
        }
      }
    }
  }

  return false;
}

export async function selectFirst(page, names, preferredValue) {
  for (const name of names) {
    const pattern = name instanceof RegExp ? name : new RegExp(`^${escapeRegex(name)}\\s*\\*?$`, 'i');
    const candidates = [
      page.getByLabel(pattern),
      page.getByRole('combobox', { name: pattern }),
    ];

    for (const locator of candidates) {
      if (await locator.count().catch(() => 0)) {
        const target = locator.first();
        if (await target.isVisible().catch(() => false)) {
          await selectPreferredOrRandom(target, preferredValue);
          await waitForPageReady(page);
          return true;
        }
      }
    }
  }

  return false;
}

export async function selectRandomCounty(page) {
  const county = page.getByLabel(/^County\s*\*?$/i)
    .or(page.getByRole('combobox', { name: /^County\s*\*?$/i }))
    .first();

  if (!(await county.count().catch(() => 0)) || !(await county.isVisible().catch(() => false))) {
    return false;
  }

  await selectPreferredOrRandom(county);
  await waitForPageReady(page);
  return true;
}

export async function fillFacilityRegistrationFields(page, user) {
  await fillFirstText(page, ['Facility Name'], user.facilityName);
  await fillFirstText(page, ['NV Business ID'], user.nvBusinessId);
  await fillFirstText(page, ['Local License #', 'Local License'], user.localLicense);
  await selectFirst(page, ['Facility Type'], user.facilityType);
  await fillAddressFields(page, user);
}

export async function fillPersonRegistrationFields(page, user) {
  await fillFirstText(page, ['Last Name'], user.lastName);
  await fillFirstText(page, ['First Name'], user.firstName);
  await fillFirstText(page, ['SSN'], user.ssn);
  await fillFirstText(page, ['API#', 'API #'], user.apiNumber);
  await fillFirstText(page, ['ARRT, NMTCB, and/or CMA'], user.arrtNumber);
  await fillAddressFields(page, user);
}

export async function fillAddressFields(page, user) {
  await fillFirstText(page, ['Street One', 'Street 1', 'Address Line 1'], user.streetOne);
  await fillFirstText(page, ['Street Two', 'Street 2', 'Address Line 2'], user.streetTwo);
  await fillFirstText(page, ['City'], user.city);

  const zipFilled = await fillFirstText(page, ['Zip', 'Zip Code'], user.zip);
  if (zipFilled) {
    await page.keyboard.press('Tab').catch(() => {});
    await waitForPageReady(page);
  }

  await selectRandomCounty(page);
  await fillFirstText(page, [/^Phone(?! Ext)/i], user.phone);
  await fillFirstText(page, ['Email'], user.email);
  await fillFirstText(page, ['Alt Email', 'Alternate Email'], user.altEmail);
}

export async function fillAccountFields(page, user) {
  await fillFirstText(page, ['Login Name'], user.loginName);
  await fillFirstText(page, [/^Password\s*\*?$/i], user.password);
  await fillFirstText(page, ['Re-type Password', 'Confirm Password'], user.password);
}

export async function submitRegistration(page) {
  const register = page.getByRole('link', { name: /^Register$/i })
    .or(page.getByRole('button', { name: /^Register$/i }))
    .first();

  await clickAndWait(page, register);
}

export async function getVisibleValidationText(page) {
  const validationText = await page
    .locator('li, .validation-summary-errors, .field-validation-error, [id*="ValidationSummary"], [id*="valSummary"], [id*="RequiredFieldValidator"], [id*="RegularExpressionValidator"]')
    .evaluateAll((elements) => elements.map((element) => element.textContent ?? '').join('\n'))
    .catch(() => '');

  return validationText
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => /required|invalid|does not match|already|unique|taken|must select|please enter/i.test(line))
    .filter((line) => !/Fields marked|Password is case sensitive/i.test(line))
    .join(' ');
}

export async function isDuplicateLoginVisible(page) {
  const bodyText = await page.locator('body').innerText().catch(() => '');
  return /login name.*(already|exists|unique|taken)|already.*login name/i.test(bodyText);
}

export async function getDuplicateProfileText(page) {
  const bodyText = await page.locator('body').innerText().catch(() => '');
  const bodyHtml = await page.locator('body').evaluate((element) => element.innerHTML).catch(() => '');
  const combined = `${bodyText}\n${bodyHtml}`;

  return /profile with this data already exists|another profile cannot be created|data already exists/i.test(combined)
    ? 'Profile with this data already exists.'
    : '';
}

export async function isRegistrationFormOpen(page) {
  const register = page.getByRole('link', { name: /^Register$/i })
    .or(page.getByRole('button', { name: /^Register$/i }))
    .first();
  const loginName = page.getByRole('textbox', { name: /Login Name\s*\*/i }).first();

  return await register.isVisible().catch(() => false)
    && await loginName.isVisible().catch(() => false);
}

export function nextLoginNameForAttempt(product, previousLoginName, attemptIndex) {
  const digitLengthIndex = Math.max(0, attemptIndex - 1);
  const digitLength = LOGIN_DIGIT_LENGTHS[Math.min(digitLengthIndex, LOGIN_DIGIT_LENGTHS.length - 1)];
  let nextLoginName;

  do {
    nextLoginName = buildLoginName(product, digitLength);
  } while (nextLoginName === previousLoginName);

  return nextLoginName;
}

async function selectPreferredOrRandom(locator, preferredValue) {
  const options = await locator.evaluate((select) => Array.from(select.options)
    .filter((option) => !option.disabled && option.value && !/^--|choose|select/i.test(option.textContent.trim()))
    .map((option) => option.value));

  if (!options.length) {
    return false;
  }

  const selectedValue = preferredValue && options.includes(String(preferredValue))
    ? String(preferredValue)
    : pick(options);

  await locator.selectOption(selectedValue);
  return true;
}

function randomNumberWithDigitLength(length) {
  if (length <= 1) {
    return String(Math.floor(Math.random() * 9) + 1);
  }

  const min = 10 ** (length - 1);
  const max = (10 ** length) - 1;
  return String(Math.floor(Math.random() * (max - min + 1)) + min);
}

function randomSsn() {
  const area = Math.floor(Math.random() * (665 - 200 + 1)) + 200;
  const group = String(Math.floor(Math.random() * 99) + 1).padStart(2, '0');
  const serial = String(Math.floor(Math.random() * 9999) + 1).padStart(4, '0');
  return `${area}-${group}-${serial}`;
}

function escapeRegex(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
