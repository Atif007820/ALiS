import { expect, test } from '@playwright/test';
import {
  LOGIN_URL,
  PRODUCT_CONFIGS,
  buildUser,
  clickAndWait,
  fillAccountFields,
  fillFacilityRegistrationFields,
  fillPersonRegistrationFields,
  getDuplicateProfileText,
  getVisibleValidationText,
  isDuplicateLoginVisible,
  isRegistrationFormOpen,
  nextLoginNameForAttempt,
  refreshProfileData,
  saveRegisteredUser,
  submitRegistration,
  waitForPageReady,
} from './NVRCP_Register_Helpers.js';

async function openProductRegistration(page, product) {
  await page.goto(LOGIN_URL, { waitUntil: 'domcontentloaded' });
  await expect(page.getByRole('row', { name: /USER LOGIN\s+Login Name/ }).first()).toBeVisible();

  await clickAndWait(page, await firstVisibleText(page, product.sectionText));
  await expect(page.getByRole('row', { name: /USER LOGIN\s+Login Name/ }).first()).toBeVisible();

  const registrationLink = product.registrationLinkId
    ? page.locator(`#${product.registrationLinkId}`)
    : page.getByRole('link', { name: product.registrationLinkName });

  await clickAndWait(page, registrationLink.first());
  await expect(page.locator('body')).toContainText(/Facility Name|Last Name|Login Name/i);
}

async function firstVisibleText(page, text) {
  for (const locator of [
    page.getByText(text, { exact: true }),
    page.getByText(text, { exact: false }),
  ]) {
    const count = await locator.count().catch(() => 0);
    for (let index = 0; index < count; index++) {
      const candidate = locator.nth(index);
      if (await candidate.isVisible().catch(() => false)) {
        return candidate;
      }
    }
  }

  return page.getByText(text, { exact: false }).first();
}

async function fillRegistrationFields(page, product, user) {
  if (product.formType === 'facility') {
    await fillFacilityRegistrationFields(page, user);
    return;
  }

  await fillPersonRegistrationFields(page, user);
}

async function submitWithRetries(page, product, user, dialogMessages) {
  let loginRetryCount = 0;

  for (let attempt = 1; attempt <= 40; attempt++) {
    await fillAccountFields(page, user);
    await submitRegistration(page);

    const dialogs = dialogMessages.splice(0);
    const duplicateLoginDialog = dialogs.find((message) => /login name.*(already|exists|unique|taken)|already.*login name/i.test(message));
    if (duplicateLoginDialog) {
      loginRetryCount += 1;
      const previousLoginName = user.loginName;
      user.loginName = nextLoginNameForAttempt(product, previousLoginName, loginRetryCount);
      console.warn(`Login name already taken. Retrying ${previousLoginName} -> ${user.loginName}`);
      continue;
    }

    const duplicateProfileDialog = dialogs.find((message) => /profile with this data already exists|another profile cannot be created|data already exists/i.test(message));
    if (duplicateProfileDialog) {
      await retryWithFreshProfile(page, product, user, duplicateProfileDialog);
      continue;
    }

    if (dialogs.length) {
      throw new Error(`Registration failed alert: ${dialogs.join(' | ')}`);
    }

    if (await isDuplicateLoginVisible(page)) {
      loginRetryCount += 1;
      const previousLoginName = user.loginName;
      user.loginName = nextLoginNameForAttempt(product, previousLoginName, loginRetryCount);
      console.warn(`Login name already taken. Retrying ${previousLoginName} -> ${user.loginName}`);
      continue;
    }

    const duplicateProfileText = await getDuplicateProfileText(page);
    if (duplicateProfileText) {
      await retryWithFreshProfile(page, product, user, duplicateProfileText);
      continue;
    }

    const validationText = await getVisibleValidationText(page);
    if (validationText) {
      throw new Error(`Registration failed validation: ${validationText}`);
    }

    if (await isRegistrationFormOpen(page)) {
      await retryWithFreshProfile(page, product, user, 'Registration form stayed open after submit.');
      continue;
    }

    return user;
  }

  throw new Error('Registration failed: duplicate login/profile message was still shown after 40 attempts.');
}

async function retryWithFreshProfile(page, product, user, reason) {
  const previousLabel = product.formType === 'facility'
    ? user.facilityName
    : `${user.firstName} ${user.lastName}`;

  refreshProfileData(product, user);

  const nextLabel = product.formType === 'facility'
    ? user.facilityName
    : `${user.firstName} ${user.lastName}`;

  console.warn(`Profile retry (${reason}) ${previousLabel} -> ${nextLabel}, keeping login ${user.loginName}`);
  await waitForPageReady(page);
  await fillRegistrationFields(page, product, user);
}

async function registerProduct(page, product, testInfo) {
  const user = buildUser(product);
  const dialogMessages = [];

  page.on('dialog', async (dialog) => {
    dialogMessages.push(dialog.message());
    await dialog.accept().catch(() => {});
  });

  testInfo.annotations.push({ type: 'Product', description: product.productName });
  testInfo.annotations.push({ type: 'Abbreviation', description: product.abbreviation });
  testInfo.annotations.push({ type: 'Login Name', description: user.loginName });
  testInfo.annotations.push({ type: 'Email', description: user.email });

  console.log(`\n-- NVRCP-${product.abbreviation} Registration --------------------------`);
  console.log('Product   :', product.productName);
  console.log('Login Name:', user.loginName);
  console.log('Email     :', user.email);
  console.log('---------------------------------------------------------------');

  await openProductRegistration(page, product);
  await waitForPageReady(page);
  await fillRegistrationFields(page, product, user);

  const registeredUser = await submitWithRetries(page, product, user, dialogMessages);
  const userDataPath = saveRegisteredUser(registeredUser);
  console.log(`Credentials saved -> ${userDataPath}`);
}

test.describe('NVRCP User Registration', () => {
  for (const product of PRODUCT_CONFIGS) {
    test(`Register ${product.productName} @${product.abbreviation}`, async ({ page }, testInfo) => {
      await registerProduct(page, product, testInfo);
    });
  }
});
