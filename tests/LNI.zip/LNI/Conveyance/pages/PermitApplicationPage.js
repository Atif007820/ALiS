import { expect } from '@playwright/test';
import { BasePage } from './BasePage.js';
import { appConfig, getApplicationTarget } from '../config/runConfig.js';
import { TEST_DATA } from '../config/editableData.js';
import {
  COMM_CONVEYANCE_TYPES,
  endorsementCodeForConveyance,
  RESIDENTIAL_CONVEYANCE_TYPES,
} from '../config/constants.js';
import {
  checkRandomAvailableRadio,
  fillField,
  isVisible,
  safeSelect,
} from '../utils/formActions.js';
import {
  pick,
  randomAlphaAddress,
  randomBuildingName,
  randomEnglishName,
  randomPhone10,
  randomSuiteAptUnit,
  randomUBI,
  randomUSCity,
  randomUSState,
  randomZip5_5,
} from '../utils/randomData.js';
import { logger } from '../utils/logger.js';
import { MachineInformationPage } from './MachineInformationPage.js';
import { DocumentUploadComponent } from './components/DocumentUploadComponent.js';

const TRANSACTION_NUMBER = /\b(?:online\s+)?transaction\s+(?:number|no\.?|#)\s*(?:is\s+)?[:#]?\s*(\d+)(?=$|[\s.,;])/i;
const EXISTING_BUILDING_QUESTION = /is the conveyance being installed in an existing building/i;

export class PermitApplicationPage extends BasePage {
  /** @param {import('@playwright/test').Page} page */
  constructor(page) {
    super(page);
    this.machineInformation  = new MachineInformationPage(page);
    this.documents           = new DocumentUploadComponent(page);
    this.confirmationHeading = page.getByRole('heading', { name: 'Confirmation', exact: true })
      .or(page.getByText('Confirmation', { exact: true }))
      .filter({ visible: true })
      .first();
  }

  async completePermitApplication({ onSelection } = {}) {
    const target = getApplicationTarget();
    const hoist = target.appType === 'CHI';
    const selection = await this.selectApplicationAndPermit(target);
    await onSelection?.(selection);
    await this.continueFromEntityInformation();
    await this.fillAddressInformation({ hoist });
    await this.fillOwnerInformation({ hoist });
    if (hoist) await this.machineInformation.fillConstructionHoist();
    else {
      await this.documents.uploadVisibleMandatoryDocuments();
      await this.machineInformation.fill();
    }
    await this.goToReviewQuestions();
    const existingBuildingAnswer = await this.answerReviewQuestions();
    await this.attestSubmitAndPayLater();
    await this.expectConfirmation();
    return { ...selection, existingBuildingAnswer };
  }

  async selectApplicationAndPermit({ appType, perType, application, permit, endorsement }) {
    await this.page.getByRole('radio', { name: application.radio, exact: true }).check();
    const byName = this.page.getByRole('radio', { name: permit.radio ?? permit.label, exact: true });
    const generic = this.page.getByRole('radio', { name: 'License Type', exact: true });
    await expect(byName.or(generic).first(), `Permit radios for ${appType} should appear`).toBeVisible();
    let radio = byName;
    if (!(await byName.count())) {
      // The recorded build exposes both permit radios with the same accessible name.
      await expect(generic, `Unexpected permit radio layout for ${appType}`).toHaveCount(Object.keys(application.permits).length);
      radio = generic.nth(permit.radioIndex);
    }
    await radio.check();
    await expect(radio).toBeChecked();

    const selection = { appType, perType };
    if (permit.endorsementFor) {
      const licenseType = permit.endorsementFor;
      const pool = licenseType === 'RESIDENTIAL' ? RESIDENTIAL_CONVEYANCE_TYPES : COMM_CONVEYANCE_TYPES;
      await this.waitForConveyanceRadios(`${perType} endorsement`);
      selection.conveyanceType = await checkRandomAvailableRadio(this.page,
        endorsement ? [endorsement.conveyanceType] : pool,
        { label: `${perType} endorsement${endorsement ? ` (${endorsement.code})` : ''}`, timeout: 10000 });
      selection.endorsementCode = endorsement?.code ?? endorsementCodeForConveyance(licenseType, selection.conveyanceType);
    }
    logger.info(`Selected ${appType} / ${perType}${selection.conveyanceType ? ` / ${selection.conveyanceType}` : ''}`);
    await this.page.getByRole('button', { name: 'Next', exact: true }).click();
    return selection;
  }

  async continueFromEntityInformation() {
    const entityNext = this.page.getByRole('button', { name: 'Next' }).nth(1);
    await this.waitForVisible(entityNext, 15000);
    await entityNext.click();
  }

  async fillAddressInformation({ hoist = false } = {}) {
    await this.page.locator('#ddlCopy_LMA').waitFor({ state: 'visible', timeout: 150000 });
    await this.waitForLoad('domcontentloaded');

    try {
      await safeSelect(this.page.locator('#ddlCopy_LMA'),    TEST_DATA.lmaCopySource);
      await fillField (this.page.locator('#ContactName_LMA'), randomEnglishName());
      if (!hoist) {
        await fillField(this.page.locator('#txtAlternatePhone_LMA'), randomPhone10());
        await fillField(this.page.locator('#txtFax_LMA'), randomPhone10());
      }

      await safeSelect(this.page.locator('#ddlCopy_SLA'),    TEST_DATA.slaCopySource);
      if (!hoist) await fillField(this.page.locator('#ContactName_SLA'), randomEnglishName());

      await fillField(this.page.getByRole('textbox', { name: 'Building Name' }),  randomBuildingName());
      if (!hoist) await fillField(this.page.getByRole('textbox', { name: 'Location Notes' }), TEST_DATA.locationNotes);

      await safeSelect(this.page.locator('#ddlCopy_CON'),    TEST_DATA.contractorCopySource);
      if (!hoist) await fillField(this.page.locator('#ContactName_CON'), randomEnglishName());
    } catch (error) {
      if (hoist) throw error;
      logger.warn(`Address step error (retrying after page settle): ${error.message.split('\n')[0]}`);
      await this.waitForLoad('networkidle');
    }

    await this.page.getByRole('button', { name: 'Next' }).nth(1).click();
    await this.waitForLoad('domcontentloaded');
  }

  async fillOwnerInformation({ hoist = false } = {}) {
    await this.waitForLoad('domcontentloaded');

    const ownerExistsDropdown = await this.openOwnerInformationDialog({ directLookup: hoist });

    let ownerExistsValue = hoist ? 'Y' : pick(TEST_DATA.ownerExistsOptions);
    const configuredExistingUbi = TEST_DATA.ownerExistingUbi;

    if (!hoist && ownerExistsValue === 'Y' && !configuredExistingUbi) {
      logger.warn('No existing owner UBI configured; using Owner Exists: N.');
      ownerExistsValue = 'N';
    }

    logger.info(`Owner Exists: ${ownerExistsValue}`);
    if (ownerExistsDropdown) await safeSelect(ownerExistsDropdown, ownerExistsValue);
    await this.waitForLoad('domcontentloaded');

    if (ownerExistsValue === 'Y') {
      const ownerExistingUbi = configuredExistingUbi;
      if (!ownerExistingUbi) {
        throw new Error('Missing existing owner UBI. Set TEST_DATA.ownerExistingUbi in editableData.js.');
      }

      logger.info(`Existing Owner UBI: ${ownerExistingUbi}`);
      await fillField(this.page.getByRole('textbox', { name: 'UBI #' }), ownerExistingUbi, { pressTab: false });
      await this.page.getByRole('button', { name: 'Search' }).click();

      const saveBtn = this.page.getByRole('button', { name: 'Save' });
      await this.waitForVisible(saveBtn, 150000);
      await saveBtn.click();
      if (hoist) await expect(saveBtn).toBeHidden();
      else await this.page.locator('mat-dialog-container').waitFor({ state: 'hidden', timeout: 150000 }).catch(() => {});
    } else {
      await fillField(this.page.locator('#txtUBI1'),                                          randomUBI());
      await fillField(this.page.getByRole('textbox', { name: 'Owner Name' }),                 randomEnglishName());
      await fillField(this.page.getByRole('textbox', { name: 'Comments' }),                   TEST_DATA.ownerComments);
      await fillField(this.page.getByRole('textbox', { name: 'Contact Name' }),               randomEnglishName());
      await fillField(this.page.getByRole('textbox', { name: 'Address' }),                    randomAlphaAddress());
      await fillField(this.page.getByRole('textbox', { name: 'City' }),                       randomUSCity());
      await fillField(this.page.getByRole('textbox', { name: 'Suite/Apt/Unit/etc.' }),        randomSuiteAptUnit());
      await safeSelect(this.page.getByLabel('State/Province'),                                randomUSState());
      await fillField(this.page.getByRole('textbox', { name: 'Zip' }),                        randomZip5_5());
      await fillField(this.page.getByRole('textbox', { name: 'Primary Phone #', exact: true }), randomPhone10());
      await fillField(this.page.getByRole('textbox', { name: 'Alternate Phone #', exact: true }), randomPhone10());
      await fillField(this.page.getByRole('textbox', { name: 'Fax' }),                        randomPhone10());
      await fillField(this.page.getByRole('textbox', { name: 'Primary E-mail' }),             TEST_DATA.businessEmail);
      await fillField(this.page.getByRole('textbox', { name: 'Alternate E-mail' }),           TEST_DATA.alternateEmail);

      const saveBtn = this.page.getByRole('button', { name: 'Save' });
      await this.waitForVisible(saveBtn, 10000);
      await saveBtn.click();
      await this.waitForLoad();
    }

    const nextAfterSave = this.page.getByRole('button', { name: 'Next' }).nth(2);
    await this.waitForVisible(nextAfterSave, 150000);
    await nextAfterSave.click();
    await this.waitForLoad('domcontentloaded');
  }

  async goToReviewQuestions() {
    // Ignore the document grid's disabled pagination button.
    const nextToReview = this.page.getByRole('button', { name: /^Next$/i, disabled: false })
      .filter({ visible: true }).last();
    await this.waitForVisible(nextToReview, 100000);
    await nextToReview.click();
  }

  async answerReviewQuestions() {
    const questionsSection = this.page.locator('sh-questions, section.questionsList-container').first();
    const hasQuestions = await questionsSection
      .waitFor({ state: 'visible', timeout: 150000 })
      .then(() => true)
      .catch(() => false);

    if (!hasQuestions) {
      logger.info('No review questions were visible; continuing to attestation.');
      return;
    }

    const questionItems = questionsSection.locator('.question-item');
    const hasQuestionItems = await questionItems.first()
      .waitFor({ state: 'visible', timeout: 15000 })
      .then(() => true)
      .catch(() => false);

    if (!hasQuestionItems) {
      logger.info('Questions section was visible, but no question rows appeared; continuing to attestation.');
      return;
    }

    const questionCount = await questionItems.count();
    let existingBuildingAnswer;
    logger.info(`Question items found: ${questionCount}`);

    for (let index = 0; index < questionCount; index++) {
      const questionItem = questionItems.nth(index);
      if (!(await isVisible(questionItem, 5000))) {
        logger.info(`Skipping review question ${index + 1}: not visible`);
        continue;
      }

      if ((await questionItem.locator('input[type="radio"]').count()) === 0) {
        logger.info(`Skipping review question ${index + 1}: no radio inputs`);
        continue;
      }

      const { questionText, answer } = await this.answerQuestionItem(questionItem, index);
      if (EXISTING_BUILDING_QUESTION.test(questionText)) existingBuildingAnswer = answer;
    }

    const unansweredQuestions = await this.getUnansweredQuestionTexts(questionsSection);
    if (unansweredQuestions.length > 0) {
      throw new Error(
        `Question tab still has unanswered required radio question(s): ${unansweredQuestions.join(' | ')}`
      );
    }
    return existingBuildingAnswer;
  }

  async attestSubmitAndPayLater() {
    const attestCheckbox = await this.openAttestationFromQuestions();
    await attestCheckbox.check();

    const submitBtn = this.page.getByRole('button', { name: 'Submit Application' });
    await this.waitForVisible(submitBtn, 100000);
    await submitBtn.click();

    const submitPayLaterBtn = this.page.getByRole('button', { name: 'Submit and Pay Later' });
    await this.waitForVisible(submitPayLaterBtn, 200000);
    await submitPayLaterBtn.click();
  }

  async expectConfirmation() {
    await expect(this.confirmationHeading).toBeVisible({ timeout: 20000 });
    logger.success('Application submitted successfully');
  }

  async getConfirmationTransaction() {
    const message = this.page.getByText(TRANSACTION_NUMBER).filter({ visible: true });
    await expect(message, 'Confirmation must show an online transaction number')
      .toBeVisible({ timeout: appConfig.timeouts.expect });

    const transactionNumber = (await message.innerText()).match(TRANSACTION_NUMBER)?.[1];
    if (!transactionNumber) {
      throw new Error('The transaction number disappeared from the Confirmation message.');
    }

    const numberText = message.getByText(transactionNumber, { exact: true }).filter({ visible: true });
    // Some deployments render the number inline instead of in its own element.
    const transactionText = await numberText.count() ? numberText : message;
    return { transactionNumber, transactionText };
  }

  // ─── Private Helpers ──────────────────────────────────────────────────────

  async answerQuestionItem(questionItem, index) {
    const questionText = await this.getQuestionText(questionItem);
    const answersToTry = this.getQuestionAnswerCandidates(questionText, index);

    for (const answer of answersToTry) {
      const checked = await this.checkQuestionRadioAnswer(questionItem, answer);
      if (checked) {
        logger.info(`Answered review question ${index + 1}: ${answer} (${questionText})`);
        return { questionText, answer };
      }
    }

    const labels = await this.getQuestionAnswerLabels(questionItem);
    throw new Error(
      `No configured answer could be selected for review question ${index + 1}: ` +
      `"${questionText}". Available answers: ${labels.join(', ')}`
    );
  }

  async getQuestionText(questionItem) {
    const text = await questionItem.locator('.q-alert span').first()
      .innerText({ timeout: 3000 })
      .catch(async () => questionItem.innerText({ timeout: 3000 }).catch(() => 'Unknown question'));

    return text.replace(/\*/g, '').replace(/\s+/g, ' ').trim();
  }

  getQuestionAnswerCandidates(questionText, index) {
    const normalizedQuestion = this.normalizeText(questionText);
    const rule = TEST_DATA.reviewQuestionAnswerRules.find(({ questionIncludes }) => (
      normalizedQuestion.includes(this.normalizeText(questionIncludes))
    ));

    const candidates = [
      rule?.answer,
      TEST_DATA.reviewAnswers[index],
      ...(TEST_DATA.reviewFallbackAnswerOrder ?? []),
    ].filter((answer) => answer && this.normalizeText(answer) !== 'yes');

    return [...new Set(candidates)];
  }

  async checkQuestionRadioAnswer(questionItem, answer) {
    const match = await questionItem.locator('input[type="radio"]').evaluateAll((inputs, answerText) => {
      const normalize = (value) => String(value ?? '').replace(/\s+/g, ' ').trim().toLowerCase();
      const wanted = normalize(answerText);

      for (const input of inputs) {
        const label = input.id ? document.querySelector(`label[for="${input.id}"]`) : null;
        const text = normalize(label?.textContent ?? input.getAttribute('aria-label') ?? input.value);
        if (text === wanted) {
          return {
            inputId: input.id,
            label: String(label?.textContent ?? input.getAttribute('aria-label') ?? input.value).trim(),
          };
        }
      }

      return null;
    }, answer);

    if (!match?.inputId) return false;

    const input = questionItem.locator(`input[id="${match.inputId}"]`).first();
    await input.scrollIntoViewIfNeeded().catch(() => {});
    await input.check({ force: true, timeout: 10000 }).catch(async () => {
      await input.evaluate((element) => {
        const label = element.id ? document.querySelector(`label[for="${element.id}"]`) : null;
        const clickable = label ?? element.closest('mat-radio-button') ?? element;
        clickable.click();
      });
    });

    const isChecked = await input.isChecked().catch(() => false);
    if (!isChecked) return false;

    logger.debug(`Selected question radio: ${match.label}`);
    return true;
  }

  async getQuestionAnswerLabels(questionItem) {
    return questionItem.locator('input[type="radio"]').evaluateAll((inputs) => (
      inputs.map((input) => {
        const label = input.id ? document.querySelector(`label[for="${input.id}"]`) : null;
        return String(label?.textContent ?? input.getAttribute('aria-label') ?? input.value).replace(/\s+/g, ' ').trim();
      }).filter(Boolean)
    )).catch(() => []);
  }

  async getUnansweredQuestionTexts(questionsSection) {
    const questionItems = questionsSection.locator('.question-item');
    const total = await questionItems.count();
    const unanswered = [];

    for (let index = 0; index < total; index++) {
      const questionItem = questionItems.nth(index);
      if ((await questionItem.locator('input[type="radio"]').count()) === 0) continue;

      const hasCheckedRadio = await questionItem.locator('input[type="radio"]').evaluateAll((inputs) => (
        inputs.some((input) => input.checked)
      )).catch(() => false);

      if (!hasCheckedRadio) {
        unanswered.push(await this.getQuestionText(questionItem));
      }
    }

    return unanswered;
  }

  async openAttestationFromQuestions() {
    const attestCheckbox = this.page.getByRole('checkbox', { name: /I attest/i }).first();
    if (await isVisible(attestCheckbox, 2000)) return attestCheckbox;

    const nextButtons = this.page.getByRole('button', { name: /^Next$/ });
    const nextCount = await nextButtons.count();
    const nextToAttest = nextCount > 1 ? nextButtons.nth(1) : nextButtons.first();

    await this.waitForVisible(nextToAttest, 100000);
    await nextToAttest.click();
    await this.waitForLoad('domcontentloaded');

    if (await isVisible(attestCheckbox, 150000)) return attestCheckbox;

    const questionsSection = this.page.locator('sh-questions, section.questionsList-container').first();
    if (await isVisible(questionsSection, 2000)) {
      const unansweredQuestions = await this.getUnansweredQuestionTexts(questionsSection);
      const pageText = await this.page.locator('main').innerText({ timeout: 5000 }).catch(() => '');
      throw new Error(
        `Could not proceed from Questions to Attestation. ` +
        `Unanswered questions: ${unansweredQuestions.join(' | ') || 'none detected'}. ` +
        `Visible page text: ${pageText.slice(0, 500)}`
      );
    }

    throw new Error(`Attestation checkbox was not visible after clicking Next. Current URL: ${this.currentUrl()}`);
  }

  normalizeText(value) {
    return String(value ?? '').replace(/\s+/g, ' ').trim().toLowerCase();
  }

  async openOwnerInformationDialog({ directLookup = false } = {}) {
    const ownerExistsDropdown = this.page.getByLabel('Does the owner already exist');
    const directUbi = this.page.getByRole('textbox', { name: 'UBI #', exact: true });
    const ownerControl = directLookup ? ownerExistsDropdown.or(directUbi).filter({ visible: true }) : ownerExistsDropdown;
    const addLinks = this.page.getByRole('link', { name: /^Add$/i });
    const addButtons = this.page.getByRole('button', { name: /^Add$/i });

    await this.waitForOwnerInformationReady(ownerControl.first(), [addLinks, addButtons]);
    if (await ownerExistsDropdown.isVisible().catch(() => false)) return ownerExistsDropdown;
    if (directLookup && await directUbi.isVisible()) return null;

    const candidates = [];

    for (const collection of [addLinks, addButtons]) {
      const count = await collection.count().catch(() => 0);
      for (let index = 0; index < count; index += 1) {
        const candidate = collection.nth(index);
        if (!(await isVisible(candidate, 1000))) continue;

        const belongsToOwnerSection = await candidate.evaluate((element) => {
          let ancestor = element.parentElement;
          while (ancestor && ancestor !== document.body) {
            const headings = ancestor.querySelectorAll('h1, h2, h3, [role="heading"]');
            if ([...headings].some((heading) => (
              String(heading.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase() === 'owner information'
            ))) return true;
            ancestor = ancestor.parentElement;
          }
          return false;
        }).catch(() => false);

        candidates.push({ locator: candidate, belongsToOwnerSection });
      }
    }

    const ownerCandidates = candidates.filter(({ belongsToOwnerSection }) => belongsToOwnerSection);
    const addOwner = ownerCandidates.length === 1
      ? ownerCandidates[0].locator
      : ownerCandidates.length === 0 && candidates.length === 1
        ? candidates[0].locator
        : null;

    if (addOwner) {
      logger.info('Opening the visible Add control in Owner Information.');
      await addOwner.scrollIntoViewIfNeeded();

      try {
        await addOwner.click({ timeout: 10000 });
      } catch (error) {
        logger.warn(`Owner Add click fallback: ${error.message.split('\n')[0]}`);
        await addOwner.evaluate((element) => element.click());
      }

      const opened = await ownerControl.first().waitFor({ state: 'visible', timeout: 15000 })
        .then(() => true)
        .catch(() => false);
      if (opened) return await ownerExistsDropdown.isVisible() ? ownerExistsDropdown : null;
    }

    const pageText = await this.page.locator('main').innerText({ timeout: 5000 }).catch(() => '');
    const loadingIndicators = await this.page.locator(
      '[aria-busy="true"], [role="progressbar"], mat-spinner, mat-progress-spinner, .loading-overlay, .loading-spinner, .spinner-overlay',
    ).evaluateAll((elements) => elements
      .filter((element) => {
        const style = window.getComputedStyle(element);
        return style.display !== 'none' && style.visibility !== 'hidden' && element.getClientRects().length > 0;
      })
      .slice(0, 5)
      .map((element) => ({
        tag: element.tagName.toLowerCase(),
        id: element.id || '',
        className: typeof element.className === 'string' ? element.className : '',
        text: String(element.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 100),
      }))
    ).catch(() => []);
    const candidateSummary = candidates.map(({ locator, belongsToOwnerSection }) => ({
      sectionMatch: belongsToOwnerSection,
      text: locator.innerText().catch(() => ''),
    }));
    const candidateDetails = await Promise.all(candidateSummary.map(async ({ sectionMatch, text }) => (
      `${await text} (owner section: ${sectionMatch})`
    )));
    throw new Error(
      `Owner Information Add dialog did not open. Current URL: ${this.currentUrl()}. ` +
      `Visible loading indicators: ${JSON.stringify(loadingIndicators)}. ` +
      `Visible Add controls: ${candidateDetails.join(' | ') || 'none'}. ` +
      `Visible page text: ${pageText.slice(0, 500)}`
    );
  }

  async waitForOwnerInformationReady(ownerExistsDropdown, addControlGroups, timeout = 60000) {
    const deadline = Date.now() + timeout;

    while (Date.now() < deadline) {
      if (await ownerExistsDropdown.isVisible().catch(() => false)) return;

      for (const controls of addControlGroups) {
        const count = await controls.count().catch(() => 0);
        for (let index = 0; index < count; index += 1) {
          if (await controls.nth(index).isVisible().catch(() => false)) return;
        }
      }

      await this.page.waitForTimeout(300);
    }
  }

  async waitForConveyanceRadios(label) {
    const iisPage = this.page.getByRole('link', { name: 'IIS' });
    if (await isVisible(iisPage, 2000)) {
      throw new Error(
        `Server returned an IIS error page instead of the application. ` +
        `Cannot select ${label}. Current URL: ${this.currentUrl()}.`
      );
    }

    const appeared = await this.page.getByRole('radio').first()
      .waitFor({ state: 'visible', timeout: 20000 })
      .then(() => true)
      .catch(() => false);

    if (!appeared) {
      throw new Error(
        `Conveyance radio buttons never appeared after selecting ${label}. ` +
        `Current URL: ${this.currentUrl()}.`
      );
    }
  }
}
