import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { openFile } from '../../utils/openArtifacts.js';
import { logger } from '../../utils/logger.js';

const root = path.dirname(fileURLToPath(import.meta.url));
const startedAt = "2026-10-12T07:17:14Z";
const reports = new Map();
for (const batch of ['modify-attempt', 'hf-verification']) {
  const batchRoot = path.join(root, batch);
  const summary = JSON.parse(await fs.readFile(path.join(batchRoot, 'latest-run-summary.json'), 'utf8'));
  const originalRoot = path.dirname(path.dirname(summary.playwrightTestReportPath));
  const relocate = (file) => file ? path.join(batchRoot, path.relative(originalRoot, file)) : '';
  for (const report of summary.reports) {
    reports.set(report.businessUnit + ':' + report.flow, {
      ...report,
      excelPath: relocate(report.excelPath),
      jsonPath: relocate(report.jsonPath),
      htmlReportPath: relocate(report.htmlReportPath),
      batchReportPath: path.join(batchRoot, 'playwright-test-report', 'index.html'),
    });
  }
}
const required = ['HF:1', 'HF:3', 'ML:1', 'EHS:1', 'CCP:1', 'RPM:1'];
assert.deepEqual([...reports.keys()].sort(), [...required].sort());
const finalReports = required.map((key) => reports.get(key));
for (const report of finalReports) {
  for (const file of [report.excelPath, report.jsonPath, report.htmlReportPath, report.batchReportPath].filter(Boolean)) {
    await fs.access(file);
  }
}
const generatedAt = new Date().toISOString();
const summary = {
  startedAt,
  generatedAt,
  elapsedMs: Date.parse(generatedAt) - Date.parse(startedAt),
  browser: 'chromium',
  executionPassed: finalReports.filter((report) => report.status === 'PASSED').length,
  executionFailed: finalReports.filter((report) => report.status !== 'PASSED').length,
  comparisonChecksPassed: finalReports.flatMap((report) => report.testResults).filter((test) => test.status === 'PASSED').length,
  comparisonChecksFailed: finalReports.flatMap((report) => report.testResults).filter((test) => test.status === 'FAILED').length,
  reports: finalReports,
};
await fs.writeFile(path.join(root, 'verification-summary.json'), JSON.stringify(summary, null, 2));
const escape = (value) => String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
const href = (file) => escape(path.relative(root, file).replaceAll('\\', '/'));
const duration = (ms) => Math.floor(ms / 60000) + 'm ' + Math.round(ms % 60000 / 1000) + 's';
const link = (label, file, download = false) => file ? '<a ' + (download ? 'download ' : '') + 'href="' + href(file) + '">' + label + '</a>' : '';
const rows = finalReports.map((report) => {
  const checks = report.testResults.map((test) => test.id + ': ' + test.status).join(', ');
  return '<tr><td>' + escape(report.businessUnit) + '</td><td>' + escape(report.flowLabel) + '</td><td>' + escape(report.status) + '</td><td>' + escape(checks || report.error) + '</td><td>' + duration(report.durationMs) + '</td><td>' + [link('HTML', report.htmlReportPath || report.batchReportPath), link('Excel', report.excelPath, true), link('JSON', report.jsonPath)].filter(Boolean).join(' | ') + '</td></tr>';
}).join('\n');
const html = '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Six Flow Verification</title><style>body{font:14px Arial,sans-serif;color:#222;max-width:1440px;margin:32px auto;padding:0 20px}h1{font-size:24px}table{border-collapse:collapse;width:100%;margin:24px 0}th,td{border:1px solid #d7dce1;padding:12px;text-align:left;vertical-align:top}th{background:#edf1f4}a{color:#075caa}p{line-height:1.6}.table-wrap{overflow-x:auto}</style></head><body><h1>Six Flow Verification</h1><p>Browser: Chromium | Execution passed: ' + summary.executionPassed + '/6 | Execution failed: ' + summary.executionFailed + ' | Elapsed: ' + duration(summary.elapsedMs) + '</p><p>Baseline comparison checks: ' + summary.comparisonChecksPassed + ' passed, ' + summary.comparisonChecksFailed + ' failed.</p><div class="table-wrap"><table><thead><tr><th>Business Unit</th><th>Flow</th><th>Execution</th><th>Baseline Checks</th><th>Duration</th><th>Reports</th></tr></thead><tbody>' + rows + '</tbody></table></div><p><a href="previous-run/index.html">Previous run</a> | <a href="modify-attempt/index.html">First verification batch</a> | <a href="hf-verification/index.html">Hospital verification batch</a> | <a href="verification-summary.json">Combined JSON</a></p></body></html>';
await fs.writeFile(path.join(root, 'index.html'), html);
await openFile('Six Flow Verification Report', path.join(root, 'index.html'), logger, { cacheBust: true });
console.log(JSON.stringify({ indexPath: path.join(root, 'index.html'), executionPassed: summary.executionPassed, executionFailed: summary.executionFailed, comparisonChecksPassed: summary.comparisonChecksPassed, comparisonChecksFailed: summary.comparisonChecksFailed, elapsedMs: summary.elapsedMs, reports: finalReports.map(({businessUnit, flow, status, durationMs, error}) => ({businessUnit, flow, status, durationMs, error})) }, null, 2));

