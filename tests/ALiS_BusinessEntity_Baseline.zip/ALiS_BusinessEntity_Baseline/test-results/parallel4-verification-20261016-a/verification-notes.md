# Four-worker runtime verification — 16 October 2026

Command: `node scripts/run.js --bu=HF,ML,EHS,CCP,RPM --url=all --flow=1,3 --tc=all --project=chromium --parallel 4 --output-dir=parallel4-verification-20261016-a`

- Ten live combinations completed: 10 runtime passes, 0 runtime failures.
- Coverage: HF, ML, EHS, CCP and RPM; New Entity–Modify and New Entity–View.
- All configured comparison checks ran: 48 checks, 6 comparison passes and 42 comparison failures. Comparison rules and workbooks were not changed.
- The previous `latest-run` directory was preserved.
- Twelve local runtime regression tests and framework validation passed.

An additional live check used the final recovery implementation with four concurrent contexts. It resumed HF, ML, EHS and RPM using their exact generated names, asserted that no create checkpoint was invoked, verified each opened identity, and captured 8, 8, 7 and 6 profile tabs respectively. All four checks passed; zero additional entities were created.

The ten-combination run verifies the historically failing combinations, not every business unit/browser permutation. See `latest-run-summary.json` and `playwright-test-report/index.html` for detailed results.
