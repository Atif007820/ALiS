// ============================================================
//  url.js
//  Change URLs, credentials, labels, and login field labels here.
// ============================================================

export const CONFIG = {
  urlA: {
    loginUrl: 'http://172.16.3.2/ALiSDPBH2TESTING11.3.24.06/login.aspx',
    username: 'EH_TP_6563',
    password: 'Password@1',
    businessUnit: 'HCQC',
    label: 'DPBH Prod',
  },

  urlB: {
    loginUrl: 'http://172.16.3.2/ALiSDPBH2TESTING11.4.40.07/login.aspx',
    username: 'EH_TP_4686',
    password: 'Password@1',
    businessUnit: 'HCQC',
    label: 'DPBH Regular',
  },

  login: {
    usernameField: 'Login Name',
    passwordField: 'Password',
    loginButton: 'Login',
  },
};
